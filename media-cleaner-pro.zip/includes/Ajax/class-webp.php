<?php
namespace MCP\Ajax;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once MCP_INCLUDES . 'Ajax/trait-ajax.php';

/**
 * WebP Compression handler — batched conversion via GD or Imagick.
 *
 * Flow:
 *  1. JS calls mcp_webp_start → returns {total}
 *  2. JS calls mcp_webp_batch → converts MCP_BATCH_SIZE images, returns stats; done when done=true
 */
final class Webp {

    use AjaxTrait;

    /** MIME types supported for WebP conversion */
    private const CONVERTIBLE = [ 'image/jpeg', 'image/png', 'image/gif' ];

    public function __construct() {
        add_action( 'wp_ajax_mcp_webp_start', [ $this, 'handle_start' ] );
        add_action( 'wp_ajax_mcp_webp_batch', [ $this, 'handle_batch' ] );
    }

    public function handle_start(): void {
        $this->verify();

        if ( ! $this->webp_supported() ) {
            wp_send_json_error( [
                'message' => __( 'WebP conversion requires GD (with WebP support) or Imagick.', 'media-cleaner-pro' ),
            ] );
        }

        global $wpdb;

        $mimes = implode( "','", array_map( 'esc_sql', self::CONVERTIBLE ) );

        $total = (int) $wpdb->get_var(
            "SELECT COUNT(ID) FROM {$wpdb->posts}
             WHERE post_type    = 'attachment'
               AND post_status  = 'inherit'
               AND post_mime_type IN ('{$mimes}')"
        );

        wp_send_json_success( [ 'total' => $total ] );
    }

    public function handle_batch(): void {
        $this->verify();

        $offset  = $this->int_param( 'offset', 0 );
        $total   = $this->int_param( 'total', 0 );
        $quality = min( 100, max( 1, $this->int_param( 'quality', MCP_WEBP_QUALITY ) ) );

        global $wpdb;

        $mimes = implode( "','", array_map( 'esc_sql', self::CONVERTIBLE ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type     = 'attachment'
               AND post_status   = 'inherit'
               AND post_mime_type IN ('{$mimes}')
             ORDER BY ID ASC
             LIMIT %d OFFSET %d",
            MCP_BATCH_SIZE,
            $offset
        ) );

        $converted  = 0;
        $saved_bytes = 0;
        $skipped    = 0;
        $items      = [];

        foreach ( $rows as $row ) {
            $id     = (int) $row->ID;
            $path   = get_attached_file( $id );
            $mime   = get_post_mime_type( $id );

            if ( ! $path || ! file_exists( $path ) ) {
                $skipped++;
                continue;
            }

            $webp_path = preg_replace( '/\.(jpe?g|png|gif)$/i', '.webp', $path );

            // Skip already converted
            if ( file_exists( $webp_path ) ) {
                $skipped++;
                continue;
            }

            $original_size = filesize( $path );
            $success       = $this->convert( $path, $webp_path, $mime, $quality );

            if ( $success && file_exists( $webp_path ) ) {
                $new_size     = filesize( $webp_path );
                $saved_bytes += max( 0, $original_size - $new_size );
                $converted++;

                $items[] = [
                    'id'       => $id,
                    'original' => size_format( $original_size, 2 ),
                    'webp'     => size_format( $new_size, 2 ),
                    'saved'    => size_format( max( 0, $original_size - $new_size ), 2 ),
                ];
            } else {
                $skipped++;
            }
        }

        $processed = $offset + count( $rows );
        $done      = $processed >= $total || count( $rows ) === 0;

        wp_send_json_success( [
            'converted'   => $converted,
            'skipped'     => $skipped,
            'saved'       => $saved_bytes,
            'saved_hr'    => size_format( $saved_bytes, 2 ),
            'items'       => $items,
            'processed'   => $processed,
            'done'        => $done,
        ] );
    }

    // ── Conversion engines ────────────────────────────────────────────────────

    private function convert( string $src, string $dest, string $mime, int $quality ): bool {
        // Try Imagick first (better quality)
        if ( class_exists( 'Imagick' ) ) {
            return $this->convert_imagick( $src, $dest, $quality );
        }

        // Fall back to GD
        if ( function_exists( 'imagewebp' ) ) {
            return $this->convert_gd( $src, $dest, $mime, $quality );
        }

        return false;
    }

    private function convert_imagick( string $src, string $dest, int $quality ): bool {
        try {
            $im = new \Imagick( $src );
            $im->setImageFormat( 'webp' );
            $im->setImageCompressionQuality( $quality );
            $im->stripImage();
            $result = $im->writeImage( $dest );
            $im->clear();
            $im->destroy();
            return (bool) $result;
        } catch ( \Exception $e ) {
            return false;
        }
    }

    private function convert_gd( string $src, string $dest, string $mime, int $quality ): bool {
        switch ( $mime ) {
            case 'image/jpeg':
                $img = @imagecreatefromjpeg( $src );
                break;
            case 'image/png':
                $img = @imagecreatefrompng( $src );
                if ( $img ) {
                    imagealphablending( $img, false );
                    imagesavealpha( $img, true );
                }
                break;
            case 'image/gif':
                $img = @imagecreatefromgif( $src );
                break;
            default:
                return false;
        }

        if ( ! $img ) return false;

        $result = imagewebp( $img, $dest, $quality );
        imagedestroy( $img );
        return (bool) $result;
    }

    private function webp_supported(): bool {
        if ( class_exists( 'Imagick' ) ) return true;
        if ( function_exists( 'imagewebp' ) ) return true;
        return false;
    }
}
