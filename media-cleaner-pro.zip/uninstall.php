<?php
/**
 * Uninstall — runs only when the user clicks "Delete" in WP admin.
 * Drops all plugin tables and removes all plugin options.
 *
 * @package Media Cleaner Pro
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}mcp_scan_results" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}mcp_trash" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}mcp_fs_duplicates" );

delete_option( 'mcp_db_version' );
delete_option( 'mcp_batch_size' );
delete_option( 'mcp_webp_quality' );
delete_option( 'mcp_large_threshold_mb' );
