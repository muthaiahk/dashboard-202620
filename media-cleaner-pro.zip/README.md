# Media Cleaner Pro

**Version:** 2.0.0  
**Requires WordPress:** 5.8+  
**Requires PHP:** 7.4+

## Features

| Feature | Description |
|---------|-------------|
| ✅ AJAX Batch Scan | Processes attachments in configurable batches — never times out |
| ✅ Unused Media Finder | Checks `post_content`, `postmeta`, `options`, `_thumbnail_id`, and `post_parent` |
| ✅ Large File Finder | Configurable threshold (default 5 MB) |
| ✅ Duplicate Image Finder | MD5 hash-based, shows original vs copies |
| ✅ Checkbox Bulk Delete | Select-all + per-row checkboxes |
| ✅ Trash Mode | `wp_trash_post()` soft-delete — fully restorable |
| ✅ WebP Compression | Imagick (preferred) or GD fallback; configurable quality slider |
| ✅ Dashboard Stats | Live widget counts loaded via AJAX |
| ✅ Settings Page | Batch size, WebP quality, large-file threshold |
| ✅ Uninstall Cleanup | Drops tables and options on plugin delete |

## Folder Structure

```
media-cleaner-pro/
├── media-cleaner-pro.php       ← Main bootstrap (constants, autoloader)
├── uninstall.php               ← Cleanup on plugin delete
│
├── includes/
│   ├── class-plugin.php        ← Singleton; wires all sub-systems
│   ├── Admin/
│   │   ├── class-menu.php      ← Admin menu + sub-pages
│   │   └── class-assets.php    ← CSS/JS enqueue (scoped to plugin pages)
│   ├── Ajax/
│   │   ├── trait-ajax.php      ← Shared nonce verify + param helpers
│   │   ├── class-scan.php      ← Batched unused/large scan
│   │   ├── class-trash.php     ← Soft delete + restore
│   │   ├── class-delete.php    ← Permanent bulk delete
│   │   ├── class-duplicates.php← MD5 duplicate finder
│   │   ├── class-webp.php      ← WebP compression (Imagick/GD)
│   │   └── class-stats.php     ← Dashboard widget counts
│   └── DB/
│       └── class-schema.php    ← dbDelta table creation + upgrade
│
├── templates/
│   ├── dashboard.php
│   ├── unused.php
│   ├── duplicates.php
│   ├── webp.php
│   ├── trash.php
│   └── settings.php
│
└── assets/
    ├── css/admin.css
    └── js/admin.js
```

## AJAX Actions

| Action | Handler | Auth |
|--------|---------|------|
| `mcp_scan_start` | Scan::handle_start | manage_options |
| `mcp_scan_batch` | Scan::handle_batch | manage_options |
| `mcp_trash` | Trash::handle_trash | manage_options |
| `mcp_restore` | Trash::handle_restore | manage_options |
| `mcp_delete` | Delete::handle | manage_options |
| `mcp_dup_start` | Duplicates::handle_start | manage_options |
| `mcp_dup_batch` | Duplicates::handle_batch | manage_options |
| `mcp_dup_groups` | Duplicates::handle_groups | manage_options |
| `mcp_webp_start` | Webp::handle_start | manage_options |
| `mcp_webp_batch` | Webp::handle_batch | manage_options |
| `mcp_stats` | Stats::handle | manage_options |

## Database Tables

| Table | Purpose |
|-------|---------|
| `{prefix}mcp_scan_results` | Caches last scan results (type, attachment_id, path, size, hash) |
| `{prefix}mcp_trash` | Logs soft-deleted attachments with original path and user |
