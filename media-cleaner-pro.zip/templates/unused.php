<?php
/**
 * Template: Unused Media Scanner
 *
 * @package Media Cleaner Pro
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="wrap mcp-wrap">

    <div class="mcp-header">
        <div class="mcp-header__logo">
            <span class="dashicons dashicons-search"></span>
            <div>
                <h1><?php esc_html_e( 'Unused Media Scanner', 'media-cleaner-pro' ); ?></h1>
                <p><?php esc_html_e( 'Find and safely remove orphaned attachments.', 'media-cleaner-pro' ); ?></p>
            </div>
        </div>
    </div>

    <!-- ── Controls bar ───────────────────────────────────────────────────── -->
    <div class="mcp-toolbar">
        <div class="mcp-toolbar__left">
            <label>
                <strong><?php esc_html_e( 'Scan Type:', 'media-cleaner-pro' ); ?></strong>
                <select id="mcp-scan-type" class="mcp-select">
                    <option value="unused"><?php esc_html_e( 'Unused Media Only',           'media-cleaner-pro' ); ?></option>
                    <option value="large"><?php  esc_html_e( 'Large Files Only (>5MB)',       'media-cleaner-pro' ); ?></option>
                    <option value="all"><?php    esc_html_e( 'All (Unused + Large)',          'media-cleaner-pro' ); ?></option>
                </select>
            </label>

            <button id="mcp-btn-scan" class="button button-primary mcp-btn-icon">
                <span class="dashicons dashicons-search"></span>
                <?php esc_html_e( 'Start Scan', 'media-cleaner-pro' ); ?>
            </button>
        </div>

        <div class="mcp-toolbar__right" id="mcp-bulk-bar" style="display:none;">
            <label>
                <input type="checkbox" id="mcp-select-all">
                <?php esc_html_e( 'Select All', 'media-cleaner-pro' ); ?>
            </label>
            <button id="mcp-btn-trash-bulk" class="button mcp-btn-icon mcp-btn-warning">
                <span class="dashicons dashicons-trash"></span>
                <?php esc_html_e( 'Move to Trash', 'media-cleaner-pro' ); ?>
            </button>
            <button id="mcp-btn-delete-bulk" class="button mcp-btn-icon mcp-btn-danger">
                <span class="dashicons dashicons-dismiss"></span>
                <?php esc_html_e( 'Delete Permanently', 'media-cleaner-pro' ); ?>
            </button>
        </div>
    </div>

    <!-- ── Progress bar ───────────────────────────────────────────────────── -->
    <div class="mcp-progress-wrap" id="mcp-progress-wrap" style="display:none;">
        <div class="mcp-progress-bar">
            <div class="mcp-progress-bar__fill" id="mcp-progress-fill"></div>
        </div>
        <p id="mcp-progress-text">0%</p>
    </div>

    <!-- ── Notice area ────────────────────────────────────────────────────── -->
    <div id="mcp-notice" class="mcp-notice" style="display:none;"></div>

    <!-- ── Results table ──────────────────────────────────────────────────── -->
    <div id="mcp-results-wrap" style="display:none;">
        <table class="mcp-table widefat">
            <thead>
                <tr>
                    <th width="30"><input type="checkbox" id="mcp-table-select-all"></th>
                    <th width="60"><?php esc_html_e( 'Preview',   'media-cleaner-pro' ); ?></th>
                    <th><?php esc_html_e( 'Title',                'media-cleaner-pro' ); ?></th>
                    <th><?php esc_html_e( 'MIME Type',            'media-cleaner-pro' ); ?></th>
                    <th><?php esc_html_e( 'File Size',            'media-cleaner-pro' ); ?></th>
                    <th><?php esc_html_e( 'Type',                 'media-cleaner-pro' ); ?></th>
                    <th><?php esc_html_e( 'Actions',              'media-cleaner-pro' ); ?></th>
                </tr>
            </thead>
            <tbody id="mcp-results-tbody"></tbody>
        </table>
    </div>

</div><!-- .wrap -->

<script>
jQuery(function ($) {

    var allItems = []; // {id, title, thumb, url, size_hr, mime, scan_type}

    // ── Scan ──────────────────────────────────────────────────────────────────
    $('#mcp-btn-scan').on('click', function () {
        allItems = [];
        $('#mcp-results-tbody').empty();
        $('#mcp-results-wrap, #mcp-bulk-bar').hide();
        $('#mcp-notice').hide();

        var scanType = $('#mcp-scan-type').val();
        $('#mcp-btn-scan').prop('disabled', true).find('.dashicons').addClass('spin');
        showProgress(0, 0);

        $.post(MCP.ajax_url, { action: 'mcp_scan_start', nonce: MCP.nonce, scan_type: scanType })
            .done(function (res) {
                if (!res.success) { showNotice(res.data.message, 'error'); resetBtn(); return; }
                runBatch(scanType, 0, res.data.total);
            })
            .fail(function () { showNotice('AJAX request failed.', 'error'); resetBtn(); });
    });

    function runBatch(type, offset, total) {
        $.post(MCP.ajax_url, {
            action: 'mcp_scan_batch', nonce: MCP.nonce,
            scan_type: type, offset: offset, total: total
        }).done(function (res) {
            if (!res.success) { showNotice(res.data.message, 'error'); resetBtn(); return; }

            var d = res.data;
            d.items.forEach(appendRow);
            allItems = allItems.concat(d.items);

            var pct = total > 0 ? Math.round((d.processed / total) * 100) : 100;
            showProgress(pct, d.processed);

            if (!d.done) {
                runBatch(type, d.processed, total);
            } else {
                resetBtn();
                if (allItems.length > 0) {
                    $('#mcp-results-wrap, #mcp-bulk-bar').show();
                    showNotice(MCP.i18n.scan_complete + ' ' + allItems.length + ' items found.', 'success');
                } else {
                    showNotice(MCP.i18n.no_items, 'info');
                }
                hideProgress();
            }
        }).fail(function () { showNotice('Batch request failed.', 'error'); resetBtn(); });
    }

    // ── Row builder ───────────────────────────────────────────────────────────
    function appendRow(item) {
        var thumb = item.thumb
            ? '<img src="' + item.thumb + '" width="50" height="50" style="object-fit:cover;border-radius:4px;">'
            : '<span class="dashicons dashicons-media-default" style="font-size:36px;"></span>';

        var typeBadge = item.scan_type === 'large'
            ? '<span class="mcp-badge mcp-badge--warning">Large</span>'
            : '<span class="mcp-badge mcp-badge--info">Unused</span>';

        var row = $('<tr data-id="' + item.id + '">').html(
            '<td><input type="checkbox" class="mcp-row-check" value="' + item.id + '"></td>' +
            '<td>' + thumb + '</td>' +
            '<td><a href="' + item.url + '" target="_blank">' + escHtml(item.title || '(no title)') + '</a></td>' +
            '<td>' + escHtml(item.mime) + '</td>' +
            '<td>' + escHtml(item.size_hr) + '</td>' +
            '<td>' + typeBadge + '</td>' +
            '<td class="mcp-row-actions">' +
                '<button class="button mcp-btn-sm mcp-btn-warning mcp-single-trash" data-id="' + item.id + '">' +
                    '<span class="dashicons dashicons-trash"></span> Trash</button> ' +
                '<button class="button mcp-btn-sm mcp-btn-danger mcp-single-delete" data-id="' + item.id + '">' +
                    '<span class="dashicons dashicons-dismiss"></span> Delete</button>' +
            '</td>'
        );
        $('#mcp-results-tbody').append(row);
    }

    // ── Single-row actions ────────────────────────────────────────────────────
    $(document).on('click', '.mcp-single-trash', function () {
        var id  = $(this).data('id');
        var row = $(this).closest('tr');
        doTrash([id], row);
    });

    $(document).on('click', '.mcp-single-delete', function () {
        if (!confirm(MCP.i18n.confirm_delete)) return;
        var id  = $(this).data('id');
        var row = $(this).closest('tr');
        doDelete([id], row);
    });

    // ── Bulk actions ──────────────────────────────────────────────────────────
    $('#mcp-select-all, #mcp-table-select-all').on('change', function () {
        $('.mcp-row-check').prop('checked', $(this).is(':checked'));
    });

    $('#mcp-btn-trash-bulk').on('click', function () {
        var ids = getChecked();
        if (!ids.length) { alert(MCP.i18n.select_one); return; }
        if (!confirm(MCP.i18n.confirm_trash)) return;
        doTrash(ids, null);
    });

    $('#mcp-btn-delete-bulk').on('click', function () {
        var ids = getChecked();
        if (!ids.length) { alert(MCP.i18n.select_one); return; }
        if (!confirm(MCP.i18n.confirm_delete)) return;
        doDelete(ids, null);
    });

    function getChecked() {
        return $.map($('.mcp-row-check:checked'), function (el) { return parseInt($(el).val()); });
    }

    // ── API calls ─────────────────────────────────────────────────────────────
    function doTrash(ids, row) {
        showNotice(MCP.i18n.trashing, 'info');
        $.post(MCP.ajax_url, { action: 'mcp_trash', nonce: MCP.nonce, ids: ids })
            .done(function (res) {
                showNotice(res.success ? res.data.message : res.data.message, res.success ? 'success' : 'error');
                if (res.success) removeRows(ids, row);
            });
    }

    function doDelete(ids, row) {
        showNotice(MCP.i18n.deleting, 'info');
        $.post(MCP.ajax_url, { action: 'mcp_delete', nonce: MCP.nonce, ids: ids })
            .done(function (res) {
                showNotice(res.success ? res.data.message : res.data.message, res.success ? 'success' : 'error');
                if (res.success) removeRows(ids, row);
            });
    }

    function removeRows(ids, row) {
        if (row) { row.fadeOut(300, function () { row.remove(); }); return; }
        ids.forEach(function (id) {
            $('tr[data-id="' + id + '"]').fadeOut(300, function () { $(this).remove(); });
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    function showProgress(pct, done) {
        $('#mcp-progress-wrap').show();
        $('#mcp-progress-fill').css('width', pct + '%');
        $('#mcp-progress-text').text(pct + '% (' + done + ' processed)');
    }

    function hideProgress() {
        setTimeout(function () { $('#mcp-progress-wrap').fadeOut(); }, 1200);
    }

    function showNotice(msg, type) {
        $('#mcp-notice')
            .removeClass('mcp-notice--success mcp-notice--error mcp-notice--info')
            .addClass('mcp-notice--' + type)
            .html(msg)
            .show();
    }

    function resetBtn() {
        $('#mcp-btn-scan').prop('disabled', false).find('.dashicons').removeClass('spin');
    }

    function escHtml(str) {
        return $('<div>').text(str).html();
    }
});
</script>
