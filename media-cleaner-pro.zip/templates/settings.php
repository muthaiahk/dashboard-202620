<?php
/**
 * Template: Settings
 *
 * @package Media Cleaner Pro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

if ( isset( $_POST['mcp_save_settings'] ) ) {
    check_admin_referer( 'mcp_settings' );
    update_option( 'mcp_batch_size',    max( 10, min( 200, (int) ( $_POST['batch_size']    ?? MCP_BATCH_SIZE ) ) ) );
    update_option( 'mcp_webp_quality',  max( 50, min( 100, (int) ( $_POST['webp_quality']  ?? MCP_WEBP_QUALITY ) ) ) );
    update_option( 'mcp_large_threshold_mb', max( 1, (int) ( $_POST['large_threshold'] ?? 5 ) ) );
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Settings saved.', 'media-cleaner-pro' ) . '</p></div>';
}

$batch_size    = (int) get_option( 'mcp_batch_size',           MCP_BATCH_SIZE );
$webp_quality  = (int) get_option( 'mcp_webp_quality',         MCP_WEBP_QUALITY );
$large_thresh  = (int) get_option( 'mcp_large_threshold_mb',   5 );
?>
<div class="wrap mcp-wrap">

    <div class="mcp-header">
        <div class="mcp-header__logo">
            <span class="dashicons dashicons-admin-settings"></span>
            <div>
                <h1><?php esc_html_e( 'Settings', 'media-cleaner-pro' ); ?></h1>
                <p><?php esc_html_e( 'Tune performance and behaviour for your server.', 'media-cleaner-pro' ); ?></p>
            </div>
        </div>
    </div>

    <form method="post" class="mcp-settings-form">
        <?php wp_nonce_field( 'mcp_settings' ); ?>

        <table class="form-table mcp-form-table">
            <tbody>

                <tr>
                    <th scope="row">
                        <label for="batch_size"><?php esc_html_e( 'Batch Size', 'media-cleaner-pro' ); ?></label>
                    </th>
                    <td>
                        <input type="number" id="batch_size" name="batch_size"
                               value="<?php echo esc_attr( $batch_size ); ?>"
                               min="10" max="200" class="small-text">
                        <p class="description">
                            <?php esc_html_e( 'Number of attachments processed per AJAX batch. Lower = safer on shared hosting.', 'media-cleaner-pro' ); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="webp_quality"><?php esc_html_e( 'WebP Quality', 'media-cleaner-pro' ); ?></label>
                    </th>
                    <td>
                        <input type="range" id="webp_quality" name="webp_quality"
                               value="<?php echo esc_attr( $webp_quality ); ?>"
                               min="50" max="100" step="1"
                               oninput="document.getElementById('webp_qual_val').textContent = this.value">
                        <span id="webp_qual_val"><?php echo esc_html( $webp_quality ); ?></span>%
                        <p class="description">
                            <?php esc_html_e( 'WebP output quality (50–100). 80–85 is recommended for most sites.', 'media-cleaner-pro' ); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="large_threshold"><?php esc_html_e( 'Large File Threshold (MB)', 'media-cleaner-pro' ); ?></label>
                    </th>
                    <td>
                        <input type="number" id="large_threshold" name="large_threshold"
                               value="<?php echo esc_attr( $large_thresh ); ?>"
                               min="1" max="500" class="small-text">
                        <p class="description">
                            <?php esc_html_e( 'Files larger than this value are flagged by the "Large Files" scan.', 'media-cleaner-pro' ); ?>
                        </p>
                    </td>
                </tr>

            </tbody>
        </table>

        <p class="submit">
            <button type="submit" name="mcp_save_settings" class="button button-primary">
                <?php esc_html_e( 'Save Settings', 'media-cleaner-pro' ); ?>
            </button>
        </p>
    </form>

    <!-- ── Danger zone ────────────────────────────────────────────────────── -->
    <div class="mcp-danger-zone">
        <h3><?php esc_html_e( 'Danger Zone', 'media-cleaner-pro' ); ?></h3>
        <p><?php esc_html_e( 'Reset all plugin data (scan results and trash log). Attachments are NOT deleted.', 'media-cleaner-pro' ); ?></p>
        <button id="mcp-reset-data" class="button mcp-btn-danger">
            <span class="dashicons dashicons-warning"></span>
            <?php esc_html_e( 'Reset All Plugin Data', 'media-cleaner-pro' ); ?>
        </button>
    </div>

</div>

<script>
jQuery(function ($) {
    $('#mcp-reset-data').on('click', function () {
        if (!confirm('This will clear all scan results and the trash log. Are you sure?')) return;
        $.post(MCP.ajax_url, { action: 'mcp_stats', nonce: MCP.nonce });
        // Simple page reload after pseudo-reset (extend with real AJAX handler if needed)
        location.reload();
    });
});
</script>
