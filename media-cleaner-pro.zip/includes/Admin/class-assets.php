<?php
namespace MCP\Admin;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Enqueues plugin CSS and JS only on plugin pages.
 */
final class Assets {

    /** Pages that require our scripts */
    private const MCP_PAGES = [
        'toplevel_page_mcp-dashboard',
        'media-cleaner_page_mcp-unused',
        'media-cleaner_page_mcp-duplicates',
        'media-cleaner_page_mcp-webp',
        'media-cleaner_page_mcp-trash',
        'media-cleaner_page_mcp-settings',
    ];

    public function __construct() {
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
    }

    public function enqueue( string $hook ): void {
        if ( ! in_array( $hook, self::MCP_PAGES, true ) ) {
            return;
        }

        // ── Styles ────────────────────────────────────────────────────────────
        wp_enqueue_style(
            'mcp-admin',
            MCP_ASSETS . 'css/admin.css',
            [],
            MCP_VERSION
        );

        // ── Scripts ───────────────────────────────────────────────────────────
        wp_enqueue_script(
            'mcp-admin',
            MCP_ASSETS . 'js/admin.js',
            [ 'jquery' ],
            MCP_VERSION,
            true                // footer
        );

        wp_localize_script( 'mcp-admin', 'MCP', [
            'ajax_url'   => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'mcp_nonce' ),
            'batch_size' => MCP_BATCH_SIZE,
            'i18n'       => [
                'scanning'         => __( 'Scanning…',           'media-cleaner-pro' ),
                'scan_complete'    => __( 'Scan complete.',       'media-cleaner-pro' ),
                'deleting'         => __( 'Deleting…',           'media-cleaner-pro' ),
                'trashing'         => __( 'Moving to trash…',    'media-cleaner-pro' ),
                'restoring'        => __( 'Restoring…',          'media-cleaner-pro' ),
                'compressing'      => __( 'Compressing…',        'media-cleaner-pro' ),
                'no_items'         => __( 'No items found.',     'media-cleaner-pro' ),
                'confirm_delete'   => __( 'Permanently delete selected items? This cannot be undone.', 'media-cleaner-pro' ),
                'confirm_trash'    => __( 'Move selected items to trash?', 'media-cleaner-pro' ),
                'select_one'       => __( 'Please select at least one item.', 'media-cleaner-pro' ),
            ],
        ] );
    }
}
