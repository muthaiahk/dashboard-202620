<?php
/**
 * Template: Deep Duplicate Finder
 *
 * @package Media Cleaner Pro
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="wrap mcp-wrap">

    <div class="mcp-header">
        <div class="mcp-header__logo">
            <span class="dashicons dashicons-admin-page"></span>
            <div>
                <h1><?php esc_html_e( 'Deep Duplicate Finder', 'media-cleaner-pro' ); ?></h1>
                <p><?php esc_html_e( 'Scans every file in wp-content/uploads/ — including orphan files not in the Media Library.', 'media-cleaner-pro' ); ?></p>
            </div>
        </div>
    </div>

    <!-- ══ Mode selector ══════════════════════════════════════════════════════ -->
    <div class="mcp-mode-tabs">
        <button class="mcp-mode-tab mcp-mode-tab--active" data-mode="auto" id="mcp-tab-auto">
            ⚡ <?php esc_html_e( 'Find & Delete (Auto)', 'media-cleaner-pro' ); ?>
        </button>
        <button class="mcp-mode-tab" data-mode="review" id="mcp-tab-review">
            🔍 <?php esc_html_e( 'Scan & Review (Manual)', 'media-cleaner-pro' ); ?>
        </button>
    </div>

    <!-- ══ AUTO MODE ══════════════════════════════════════════════════════════ -->
    <div id="mcp-panel-auto">

        <div class="mcp-card-info">
            <span class="dashicons dashicons-info-outline" style="color:#2271b1;"></span>
            <?php esc_html_e( 'Automatically scans uploads/ for duplicate files, checks if each file is used on any page/post, and permanently deletes only safe copies. Originals and in-use files are always kept.', 'media-cleaner-pro' ); ?>
        </div>

        <div class="mcp-toolbar">
            <button id="mcp-find-delete-btn" class="button button-primary mcp-btn-icon mcp-btn-large">
                <span class="dashicons dashicons-trash"></span>
                <?php esc_html_e( 'Find & Delete All Duplicates', 'media-cleaner-pro' ); ?>
            </button>
        </div>

        <!-- Spinner / status -->
        <div id="mcp-fd-spinner" style="display:none;margin:40px 0;text-align:center;">
            
            <div class="mcp-person-anim-wrap">
                <svg viewBox="0 0 200 120" width="280" height="150" style="margin: 0 auto; display: block; overflow: visible;">
                    <!-- Ground -->
                    <line x1="-20" y1="100" x2="220" y2="100" stroke="#c3c4c7" stroke-width="3" stroke-linecap="round"/>
                    
                    <!-- Dustbin -->
                    <g class="mcp-bin" style="transform-origin: 157px 100px;">
                        <path d="M142,65 L172,65 L168,98 L146,98 Z" fill="#d63638" stroke="#a0292a" stroke-width="2"/>
                        <rect x="138" y="60" width="38" height="5" fill="#a0292a" rx="2" />
                        <rect x="150" y="55" width="14" height="5" fill="#a0292a" rx="1"/>
                        <line x1="150" y1="70" x2="152" y2="92" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
                        <line x1="164" y1="70" x2="162" y2="92" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
                        <line x1="157" y1="70" x2="157" y2="92" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity="0.4"/>
                    </g>

                    <!-- Document -->
                    <g class="mcp-doc">
                        <rect x="0" y="0" width="16" height="20" fill="#fff" stroke="#2271b1" stroke-width="1.5" rx="1"/>
                        <line x1="4" y1="4" x2="12" y2="4" stroke="#2271b1" stroke-width="1.5" stroke-linecap="round"/>
                        <line x1="4" y1="9" x2="12" y2="9" stroke="#2271b1" stroke-width="1.5" stroke-linecap="round"/>
                        <line x1="4" y1="14" x2="8" y2="14" stroke="#2271b1" stroke-width="1.5" stroke-linecap="round"/>
                    </g>
                    
                    <!-- Person -->
                    <g class="mcp-person" style="transform-origin: 20px 75px;">
                        <g transform="translate(0, 50)">
                            <!-- Back Leg -->
                            <path class="mcp-leg-back" style="transform-origin: 20px 30px;" d="M20,30 L10,48" stroke="#3c434a" stroke-width="5" stroke-linecap="round"/>
                            <!-- Front Leg -->
                            <path class="mcp-leg-front" style="transform-origin: 20px 30px;" d="M20,30 L30,48" stroke="#3c434a" stroke-width="5" stroke-linecap="round"/>
                            <!-- Body -->
                            <line x1="20" y1="14" x2="20" y2="32" stroke="#3c434a" stroke-width="6" stroke-linecap="round"/>
                            <!-- Head -->
                            <circle cx="20" cy="8" r="8" fill="#3c434a" />
                            <!-- Arm holding file -->
                            <path class="mcp-arm" style="transform-origin: 20px 18px;" d="M20,18 Q30,18 35,15" fill="none" stroke="#3c434a" stroke-width="4" stroke-linecap="round"/>
                        </g>
                    </g>
                </svg>
            </div>

            <h3 id="mcp-fd-status" style="margin-top:16px;color:#2271b1;font-size:16px;font-weight:600;">
                <?php esc_html_e( 'Scanning & Deleting Duplicates…', 'media-cleaner-pro' ); ?>
            </h3>
            <p style="color:#646970;font-size:13px;margin-top:4px;">
                <?php esc_html_e( 'Please wait. This might take a few minutes for large libraries.', 'media-cleaner-pro' ); ?>
            </p>
        </div>

        <!-- Result card -->
        <div id="mcp-fd-result" style="display:none;"></div>

    </div>

    <!-- ══ MANUAL REVIEW MODE ═════════════════════════════════════════════════ -->
    <div id="mcp-panel-review" style="display:none;">

        <div class="mcp-toolbar" style="flex-wrap:wrap;gap:10px;">
            <button id="mcp-deep-scan-btn" class="button button-primary mcp-btn-icon">
                <span class="dashicons dashicons-search"></span>
                <?php esc_html_e( 'Deep Scan uploads/', 'media-cleaner-pro' ); ?>
            </button>

            <button id="mcp-deep-delete-selected" class="button mcp-btn-danger mcp-btn-icon" style="display:none;">
                <span class="dashicons dashicons-trash"></span>
                <?php esc_html_e( 'Delete Selected Copies', 'media-cleaner-pro' ); ?>
            </button>

            <button id="mcp-deep-delete-all-copies" class="button mcp-btn-danger mcp-btn-icon" style="display:none;">
                <span class="dashicons dashicons-warning"></span>
                <?php esc_html_e( 'Delete ALL Copies (keep originals)', 'media-cleaner-pro' ); ?>
            </button>

            <label id="mcp-deep-select-all-wrap" style="display:none;align-self:center;">
                <input type="checkbox" id="mcp-deep-select-all">
                <?php esc_html_e( 'Select all copies', 'media-cleaner-pro' ); ?>
            </label>
        </div>

        <!-- Progress -->
        <div class="mcp-progress-wrap" id="mcp-deep-progress" style="display:none;">
            <div class="mcp-progress-bar">
                <div class="mcp-progress-bar__fill" id="mcp-deep-fill"></div>
            </div>
            <p id="mcp-deep-text">0%</p>
        </div>

        <!-- Conveyor Belt File Check Animation -->
        <div id="mcp-person-scan-anim" style="display:none; text-align:center; padding: 30px 0;">
            <div style="max-width: 600px; margin: 0 auto; overflow: hidden; border-radius: 8px;">
                <svg viewBox="0 0 400 160" width="100%" height="auto" style="display:block;">
                    <defs>
                        <!-- Good Folder -->
                        <g id="mcpGF">
                            <path d="M0,8 L10,-2 L40,-2 L40,30 L0,30 Z" fill="#eab308" stroke="#ca8a04" stroke-width="2"/>
                            <rect x="10" y="5" width="20" height="20" fill="#fff" stroke="#9ca3af" stroke-width="1.5" rx="1"/>
                            <path d="M-5,10 L35,10 L40,30 L0,30 Z" fill="#fef08a" stroke="#ca8a04" stroke-width="2" stroke-linejoin="round"/>
                        </g>
                        <!-- Bad Folder -->
                        <g id="mcpBF">
                            <path d="M0,8 L10,-2 L40,-2 L40,30 L0,30 Z" fill="#eab308" stroke="#ca8a04" stroke-width="2"/>
                            <rect x="2" y="-12" width="16" height="25" fill="#fff" stroke="#d63638" stroke-width="1.5" rx="1"/>
                            <line x1="6" y1="-5" x2="14" y2="-5" stroke="#d63638" stroke-width="1.5"/>
                            <rect x="20" y="-12" width="16" height="25" fill="#fff" stroke="#d63638" stroke-width="1.5" rx="1"/>
                            <line x1="24" y1="-5" x2="32" y2="-5" stroke="#d63638" stroke-width="1.5"/>
                            <path d="M-5,10 L35,10 L40,30 L0,30 Z" fill="#fef08a" stroke="#ca8a04" stroke-width="2" stroke-linejoin="round"/>
                        </g>
                    </defs>

                    <!-- Conveyor Belt -->
                    <g class="mcp-conveyor-belt">
                        <line x1="-100" y1="130" x2="900" y2="130" stroke="#646970" stroke-width="4"/>
                    </g>

                    <!-- Folders Track -->
                    <g class="mcp-folders-track">
                        <!-- Normal Folders -->
                        <use href="#mcpGF" x="130" y="100"/>
                        <use href="#mcpGF" x="370" y="100"/>
                        <use href="#mcpGF" x="490" y="100"/>
                        <!-- Bad Folder -->
                        <use href="#mcpBF" x="250" y="100" class="mcp-bad-kicked" style="transform-origin: 270px 115px;"/>

                        <!-- Loop identicals -->
                        <use href="#mcpGF" x="610" y="100"/>
                        <use href="#mcpBF" x="730" y="100" class="mcp-bad-kicked" style="transform-origin: 750px 115px;"/>
                        <use href="#mcpGF" x="850" y="100"/>
                        <use href="#mcpGF" x="970" y="100"/>
                    </g>

                    <!-- Person -->
                    <g transform="translate(60, 60)">
                        <!-- Back Leg -->
                        <path d="M20,30 L25,70" fill="none" stroke="#2271b1" stroke-width="6" stroke-linecap="round"/>
                        <!-- Body -->
                        <line x1="20" y1="30" x2="30" y2="-5" stroke="#2271b1" stroke-width="7" stroke-linecap="round"/>
                        <!-- Head -->
                        <circle cx="35" cy="-20" r="10" fill="#2271b1" />
                        
                        <!-- Shock lines -->
                        <g class="mcp-shock-lines">
                            <line x1="20" y1="-30" x2="15" y2="-40" stroke="#d63638" stroke-width="2" stroke-linecap="round"/>
                            <line x1="35" y1="-35" x2="35" y2="-45" stroke="#d63638" stroke-width="2" stroke-linecap="round"/>
                            <line x1="50" y1="-30" x2="55" y2="-40" stroke="#d63638" stroke-width="2" stroke-linecap="round"/>
                        </g>

                        <!-- Kick Leg (front leg) -->
                        <g class="mcp-kick-leg" style="transform-origin: 20px 30px;">
                            <path d="M20,30 L30,45 L40,70" fill="none" stroke="#2271b1" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
                        </g>

                        <!-- Arms checking -->
                        <g class="mcp-check-arm" style="transform-origin: 30px 0px;">
                            <path d="M30,0 Q45,10 60,25" fill="none" stroke="#2271b1" stroke-width="5" stroke-linecap="round"/>
                            <circle cx="65" cy="30" r="8" fill="rgba(34, 113, 177, 0.2)" stroke="#d63638" stroke-width="3"/>
                            <line x1="60" y1="25" x2="62" y2="26" stroke="#2271b1" stroke-width="2"/>
                        </g>
                    </g>
                </svg>
            </div>
        </div>

        <!-- Stats bar -->
        <div id="mcp-deep-stats" style="display:none;margin:12px 0;padding:10px 16px;background:#f0f6fc;border-left:4px solid #2271b1;border-radius:4px;font-size:13px;">
            <strong><?php esc_html_e( 'Scan summary:', 'media-cleaner-pro' ); ?></strong>
            <span id="mcp-deep-stat-groups"></span> &nbsp;|&nbsp;
            <span id="mcp-deep-stat-files"></span> &nbsp;|&nbsp;
            <?php esc_html_e( 'Reclaimable:', 'media-cleaner-pro' ); ?> <strong id="mcp-deep-stat-saved" style="color:#d63638;"></strong>
        </div>

        <!-- Results table -->
        <div id="mcp-deep-results"></div>

    </div>

    <!-- Shared notice -->
    <div id="mcp-deep-notice" class="mcp-notice" style="display:none;margin-top:12px;"></div>

</div>

<style>
/* ── Mode tabs ─────────────────────────────────────────────────────────── */
.mcp-mode-tabs        { display:flex;gap:0;margin:16px 0 0;border-bottom:2px solid #ddd; }
.mcp-mode-tab         { background:none;border:none;border-bottom:2px solid transparent;margin-bottom:-2px;padding:8px 18px;font-size:13px;font-weight:600;cursor:pointer;color:#646970; }
.mcp-mode-tab--active { border-bottom-color:#2271b1;color:#2271b1; }
.mcp-mode-tab:hover   { color:#2271b1; }

/* ── Panels ───────────────────────────────────────────────────────────── */
#mcp-panel-auto, #mcp-panel-review { padding-top:16px; }

/* ── Card info ────────────────────────────────────────────────────────── */
.mcp-card-info        { display:flex;align-items:flex-start;gap:8px;padding:12px 16px;background:#f0f6fc;border-left:4px solid #2271b1;border-radius:4px;font-size:13px;margin-bottom:16px;line-height:1.6; }

/* ── Large btn ────────────────────────────────────────────────────────── */
.mcp-btn-large        { font-size:14px!important;padding:6px 18px!important;height:auto!important; }

/* ── Result card ──────────────────────────────────────────────────────── */
.mcp-result-card      { border-radius:8px;overflow:hidden;margin-top:16px;box-shadow:0 1px 4px rgba(0,0,0,.08); }
.mcp-result-card__head{ padding:16px 20px;color:#fff;font-size:14px;font-weight:600;display:flex;align-items:center;gap:10px; }
.mcp-result-card__body{ padding:16px 20px;background:#fff;border:1px solid #ddd;border-top:none;font-size:13px;line-height:1.8; }
.mcp-result-card--success .mcp-result-card__head { background:#00a32a; }
.mcp-result-card--info    .mcp-result-card__head { background:#2271b1; }
.mcp-result-card--warning .mcp-result-card__head { background:#d63638; }
.mcp-stat-grid        { display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:12px;margin-bottom:12px; }
.mcp-stat-box         { background:#f6f7f7;border-radius:6px;padding:12px;text-align:center; }
.mcp-stat-box__num    { font-size:26px;font-weight:700;line-height:1; }
.mcp-stat-box__label  { font-size:11px;color:#666;margin-top:4px; }
.mcp-stat-box--green  .mcp-stat-box__num { color:#00a32a; }
.mcp-stat-box--red    .mcp-stat-box__num { color:#d63638; }
.mcp-stat-box--amber  .mcp-stat-box__num { color:#b45309; }
.mcp-stat-box--blue   .mcp-stat-box__num { color:#2271b1; }

/* ── Review-mode table ────────────────────────────────────────────────── */
.mcp-deep-group          { margin:18px 0;border:1px solid #ddd;border-radius:6px;overflow:hidden; }
.mcp-deep-group-header   { display:flex;align-items:center;gap:10px;padding:10px 14px;background:#f6f7f7;border-bottom:1px solid #ddd;flex-wrap:wrap; }
.mcp-deep-group-title    { font-weight:600;font-size:13px;flex:1; }
.mcp-deep-group-hash     { font-family:monospace;font-size:11px;color:#888; }
.mcp-deep-group-body     { overflow-x:auto; }
.mcp-deep-table          { width:100%;border-collapse:collapse;font-size:13px; }
.mcp-deep-table th       { padding:8px 10px;text-align:left;background:#fafafa;border-bottom:1px solid #eee;font-weight:600; }
.mcp-deep-table td       { padding:8px 10px;border-bottom:1px solid #f0f0f0;vertical-align:middle; }
.mcp-deep-table tr:last-child td { border-bottom:none; }
.mcp-deep-table tr.mcp-original  { background:#f0fff4; }
.mcp-deep-table tr.mcp-copy      { background:#fff; }
.mcp-thumb-sm            { width:48px;height:48px;object-fit:cover;border-radius:4px;border:1px solid #ddd; }
.mcp-no-thumb-sm         { width:48px;height:48px;background:#eee;display:flex;align-items:center;justify-content:center;border-radius:4px; }
.mcp-badge               { display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600; }
.mcp-badge--success      { background:#d1fae5;color:#065f46; }
.mcp-badge--warning      { background:#fef3c7;color:#92400e; }
.mcp-badge--orphan       { background:#fee2e2;color:#991b1b; }
.mcp-deep-table .mcp-path{ font-family:monospace;font-size:11px;word-break:break-all;color:#555; }

/* ── Person Animation ─────────────────────────────────────────────────── */
.mcp-person-anim-wrap { position: relative; }
.mcp-person { animation: mcpWalk 3.5s infinite linear; }
.mcp-leg-front { animation: mcpLeg 0.5s infinite linear; }
.mcp-leg-back { animation: mcpLeg 0.5s infinite linear reverse; }
.mcp-arm { animation: mcpArm 3.5s infinite linear; }
.mcp-doc { animation: mcpDoc 3.5s infinite linear; }
.mcp-bin { animation: mcpBin 3.5s infinite linear; }

@keyframes mcpWalk {
    0%   { transform: translateX(-10px); }
    35%  { transform: translateX(95px); }
    45%  { transform: translateX(95px); }
    55%  { transform: translateX(95px) scaleX(-1); }
    90%  { transform: translateX(-10px) scaleX(-1); }
    100% { transform: translateX(-10px); }
}

@keyframes mcpLeg {
    0%, 100% { transform: rotate(0); }
    25% { transform: rotate(25deg); }
    75% { transform: rotate(-25deg); }
}

@keyframes mcpArm {
    0%, 35% { transform: rotate(0); }
    38% { transform: rotate(-45deg); }
    42% { transform: rotate(20deg); }
    45%, 100% { transform: rotate(0); }
}

@keyframes mcpDoc {
    0%  { opacity: 1; transform: translate(25px, 65px); }
    35% { opacity: 1; transform: translate(130px, 65px); }
    38% { opacity: 1; transform: translate(120px, 45px) rotate(-20deg); }
    42% { opacity: 1; transform: translate(145px, 35px) rotate(45deg); }
    45% { opacity: 0; transform: translate(157px, 65px) rotate(90deg); }
    100% { opacity: 0; transform: translate(157px, 65px); }
}

@keyframes mcpBin {
    0%, 43% { transform: rotate(0); }
    45% { transform: rotate(-6deg); }
    47% { transform: rotate(6deg); }
    49% { transform: rotate(-4deg); }
    51% { transform: rotate(4deg); }
    53%, 100% { transform: rotate(0); }
}

/* ── Conveyor Belt Animation ────────────────────────────────────────────── */
.mcp-folders-track { animation: mcpTrackMove 8s infinite ease-in-out; }
.mcp-check-arm     { animation: mcpArmCheck 8s infinite ease-in-out; }
.mcp-kick-leg      { animation: mcpKickLeg 8s infinite ease-in-out; }
.mcp-bad-kicked    { animation: mcpBadFolderKick 8s infinite ease-in-out; }
.mcp-shock-lines   { animation: mcpShock 8s infinite linear; opacity: 0; }

@keyframes mcpTrackMove {
    0%, 15%   { transform: translateX(0); }
    25%, 40%  { transform: translateX(-120px); }
    50%, 65%  { transform: translateX(-240px); }
    75%, 90%  { transform: translateX(-360px); }
    100%      { transform: translateX(-480px); }
}

@keyframes mcpArmCheck {
    0%, 15% { transform: rotate(15deg); }
    20% { transform: rotate(-5deg); }   
    25%, 28% { transform: rotate(15deg); }
    30%, 38% { transform: rotate(-35deg); } /* shock! */
    45% { transform: rotate(-5deg); }
    50%, 65% { transform: rotate(15deg); }
    70% { transform: rotate(-5deg); }
    75%, 90% { transform: rotate(15deg); }
    95% { transform: rotate(-5deg); }
    100% { transform: rotate(15deg); }
}

@keyframes mcpKickLeg {
    0%, 28% { transform: rotate(0); }
    30%, 36% { transform: rotate(-55deg) translateX(15px) translateY(5px); }
    40%, 100% { transform: rotate(0); }
}

@keyframes mcpBadFolderKick {
    0%, 28% { transform: translate(0, 0) rotate(0); opacity: 1; }
    30% { transform: translate(30px, -60px) rotate(45deg); opacity: 1; }
    36% { transform: translate(140px, -150px) rotate(180deg); opacity: 0; }
    37%, 100% { transform: translate(0, 0); opacity: 0; }
}

@keyframes mcpShock {
    0%, 27% { opacity: 0; transform: scale(0.5); }
    28%, 32% { opacity: 1; transform: scale(1.1); }
    34%, 100% { opacity: 0; transform: scale(0.5); }
}
</style>

<script>
jQuery(function ($) {
    'use strict';

    /* ════════════════════════════════════════════════════════════════════════
       Mode tabs
    ════════════════════════════════════════════════════════════════════════ */
    $('.mcp-mode-tab').on('click', function () {
        var mode = $(this).data('mode');
        $('.mcp-mode-tab').removeClass('mcp-mode-tab--active');
        $(this).addClass('mcp-mode-tab--active');
        $('#mcp-panel-auto, #mcp-panel-review').hide();
        $('#mcp-panel-' + mode).show();
        $('#mcp-deep-notice').hide();
    });

    /* ════════════════════════════════════════════════════════════════════════
       AUTO MODE — Find & Delete
    ════════════════════════════════════════════════════════════════════════ */
    $('#mcp-find-delete-btn').on('click', function () {
        if ( ! confirm('⚠️ This will permanently delete all duplicate copy files (keeping one original per group).\n\nFiles used on any page or post will be protected.\n\nContinue?') ) return;

        var $btn = $(this);
        $btn.prop('disabled', true).find('.dashicons').addClass('spin');
        $('#mcp-fd-result').hide();
        $('#mcp-deep-notice').hide();
        $('#mcp-fd-spinner').show();
        // The animated SVG handles the visual loading

        $.ajax({
            url:     MCP.ajax_url,
            method:  'POST',
            timeout: 300000, // 5 min timeout for large libraries
            data:    { action: 'mcp_deep_dup_find_delete', nonce: MCP.nonce }
        })
        .done(function (res) {
            $('#mcp-fd-spinner').hide();
            $btn.prop('disabled', false).find('.dashicons').removeClass('spin');

            if ( ! res.success ) {
                notice('❌ ' + (res.data ? res.data.message : 'Unknown error'), 'error');
                return;
            }

            renderResultCard(res.data);
        })
        .fail(function (xhr) {
            $('#mcp-fd-spinner').hide();
            $btn.prop('disabled', false).find('.dashicons').removeClass('spin');
            var msg = 'AJAX error';
            if (xhr.responseText) {
                // Try to extract PHP error from response
                var plain = $('<div>').html(xhr.responseText).text().substring(0, 200);
                msg += ': ' + plain;
            }
            notice('❌ ' + msg, 'error');
        });
    });

    function renderResultCard(d) {
        var hasDeleted  = d.deleted > 0;
        var hasSkipped  = d.skipped > 0;
        var hasErrors   = d.errors && d.errors.length > 0;
        var allClean    = d.groups === 0;
        var cardClass   = allClean ? 'mcp-result-card--info' : (hasDeleted ? 'mcp-result-card--success' : 'mcp-result-card--warning');
        var icon        = allClean ? '✅' : (hasDeleted ? '🗑️' : '🔒');
        var headTitle   = allClean ? 'No duplicates found — uploads/ is clean!' : 'Find & Delete Complete';

        var html =
            '<div class="mcp-result-card ' + cardClass + '">' +
            '<div class="mcp-result-card__head"><span style="font-size:20px;">' + icon + '</span> ' + headTitle + '</div>' +
            '<div class="mcp-result-card__body">' +

            '<div class="mcp-stat-grid">' +
                statBox(d.scanned,  'Files scanned',     'blue') +
                statBox(d.groups,   'Duplicate groups',  d.groups > 0 ? 'red' : 'green') +
                statBox(d.deleted,  'Copies deleted',    d.deleted > 0 ? 'green' : 'blue') +
                statBox(d.freed_hr, 'Space freed',       d.deleted > 0 ? 'green' : 'blue', true) +
                statBox(d.skipped,  'Protected (in use)',d.skipped > 0 ? 'amber' : 'blue') +
            '</div>' +

            '<p style="border-top:1px solid #eee;padding-top:10px;font-size:13px;"><strong>' + esc(d.message) + '</strong></p>';

        if (hasSkipped && d.protected && d.protected.length) {
            html += '<p style="color:#b45309;font-size:12px;">🔒 Protected files (still in use on a page/post — not deleted):<br>';
            html += d.protected.map(function(f){ return '<code>' + esc(f) + '</code>'; }).join(', ');
            html += '</p>';
        }

        if (hasErrors) {
            html += '<p style="color:#d63638;font-size:12px;">⚠️ Errors:<br>';
            html += d.errors.map(function(e){ return '<code>' + esc(e) + '</code>'; }).join('<br>');
            html += '</p>';
        }

        html += '</div></div>';

        $('#mcp-fd-result').html(html).show();
    }

    function statBox(val, label, color, noNum) {
        return '<div class="mcp-stat-box mcp-stat-box--' + color + '">' +
            '<div class="mcp-stat-box__num">' + (noNum ? esc(String(val)) : val) + '</div>' +
            '<div class="mcp-stat-box__label">' + label + '</div>' +
            '</div>';
    }

    /* ════════════════════════════════════════════════════════════════════════
       MANUAL REVIEW MODE — batched scan + manual delete
    ════════════════════════════════════════════════════════════════════════ */
    var scanTotal = 0;

    $('#mcp-deep-scan-btn').on('click', function () {
        $('#mcp-deep-results').empty();
        $('#mcp-deep-notice').hide();
        $('#mcp-deep-stats').hide();
        $('#mcp-deep-delete-selected, #mcp-deep-delete-all-copies, #mcp-deep-select-all-wrap').hide();
        setBtn(true);

        $.post(MCP.ajax_url, { action: 'mcp_deep_dup_start', nonce: MCP.nonce })
            .done(function (res) {
                if (!res.success) { notice(res.data.message, 'error'); setBtn(false); return; }
                scanTotal = res.data.total;
                if (scanTotal === 0) { notice('No files found in uploads/ directory.', 'info'); setBtn(false); return; }
                notice('Indexing ' + scanTotal + ' files — hashing in batches…', 'info');
                progShow();
                runBatch(0);
            })
            .fail(function (xhr) { ajaxErr(xhr, 'scan start'); setBtn(false); });
    });

    function runBatch(offset) {
        progUpdate(offset);
        $.post(MCP.ajax_url, { action: 'mcp_deep_dup_batch', nonce: MCP.nonce, offset: offset, total: scanTotal })
        .done(function (res) {
            if (!res.success) { notice(res.data.message, 'error'); setBtn(false); progHide(); return; }
            var d = res.data;
            if (!d.done) { runBatch(d.processed); }
            else { progUpdate(scanTotal); setTimeout(function () { progHide(); loadGroups(); }, 600); }
        })
        .fail(function (xhr) { ajaxErr(xhr, 'batch hashing'); setBtn(false); progHide(); });
    }

    function loadGroups() {
        $.post(MCP.ajax_url, { action: 'mcp_deep_dup_groups', nonce: MCP.nonce })
            .done(function (res) {
                setBtn(false);
                if (!res.success) { notice(res.data.message, 'error'); return; }
                var d = res.data;
                if (!d.groups || d.groups.length === 0) {
                    notice('✅ No duplicate files found! Your uploads/ folder is clean.', 'success'); return;
                }
                $('#mcp-deep-stat-groups').text(d.groups.length + ' duplicate group(s)');
                $('#mcp-deep-stat-files').text(d.total_files + ' duplicate file(s) total');
                $('#mcp-deep-stat-saved').text(d.total_saved + ' reclaimable');
                $('#mcp-deep-stats').show();
                renderGroups(d.groups);
                notice('⚠️ Found ' + d.groups.length + ' group(s) of duplicate files. Review below and delete copies.', 'error');
                $('#mcp-deep-delete-selected, #mcp-deep-delete-all-copies, #mcp-deep-select-all-wrap').show();
            })
            .fail(function (xhr) { ajaxErr(xhr, 'loading results'); setBtn(false); });
    }

    function renderGroups(groups) {
        var html = '';
        groups.forEach(function (group, gi) {
            var totalSize = group.reduce(function (s, item) { return s + item.file_size; }, 0);
            html +=
                '<div class="mcp-deep-group" id="mcp-group-' + gi + '">' +
                '<div class="mcp-deep-group-header">' +
                    '<span class="mcp-deep-group-title">Duplicate Group #' + (gi + 1) +
                        ' <small>(' + group.length + ' copies, ' + MCP_Utils.formatBytes(totalSize) + ' total)</small></span>' +
                    '<span class="mcp-deep-group-hash">MD5: ' + esc(group[0].hash) + '</span>' +
                    '<button class="button mcp-btn-sm mcp-btn-danger mcp-del-group-copies" data-group="' + gi + '">🗑 Delete All Copies</button>' +
                '</div>' +
                '<div class="mcp-deep-group-body">' +
                '<table class="mcp-deep-table"><thead><tr>' +
                '<th></th><th></th><th>File</th><th>Path</th><th>Size</th><th>Type</th><th>Action</th>' +
                '</tr></thead><tbody>';

            group.forEach(function (item, i) {
                var isOriginal  = (i === 0);
                var row_class   = isOriginal ? 'mcp-original' : 'mcp-copy';
                var badge       = isOriginal ? '<span class="mcp-badge mcp-badge--success">Original</span>' : '<span class="mcp-badge mcp-badge--warning">Copy</span>';
                var orphanBadge = item.is_orphan ? ' <span class="mcp-badge mcp-badge--orphan">Orphan</span>' : '';
                var inUseBadge  = item.in_use ? ' <span class="mcp-badge" style="background:#fef9c3;color:#92400e;">🔒 In Use</span>' : '';
                var thumb       = item.thumb
                    ? '<img src="' + esc(item.thumb) + '" class="mcp-thumb-sm">'
                    : '<div class="mcp-no-thumb-sm"><span class="dashicons dashicons-media-default"></span></div>';
                var titleLink   = item.url && !item.is_orphan
                    ? '<a href="' + esc(item.url) + '" target="_blank">' + esc(item.title) + '</a>'
                    : esc(item.file_name);
                var checkbox = !isOriginal
                    ? '<input type="checkbox" class="mcp-deep-check" value="' + item.row_id + '" data-group="' + gi + '" ' + (item.in_use ? 'disabled title="Protected"' : '') + '>'
                    : '';
                var action = isOriginal
                    ? '<em style="color:#888;font-size:12px;">Keep (original)</em>'
                    : (item.in_use
                        ? '<span style="color:#b45309;font-size:13px;">🔒 Protected</span>'
                        : '<button class="button mcp-btn-sm mcp-btn-danger mcp-del-single" data-row-id="' + item.row_id + '">Delete</button>');

                html += '<tr class="' + row_class + '" id="mcp-row-' + item.row_id + '">' +
                    '<td>' + checkbox + '</td>' +
                    '<td>' + thumb + '</td>' +
                    '<td>' + badge + orphanBadge + inUseBadge + '<br><span style="font-size:12px;">' + titleLink + '</span></td>' +
                    '<td><span class="mcp-path">' + esc(item.file_path) + '</span></td>' +
                    '<td>' + esc(item.size_hr) + '</td>' +
                    '<td>' + (item.is_orphan ? '🔴 Orphan' : '🟢 WP Media') + '</td>' +
                    '<td>' + action + '</td>' +
                    '</tr>';
            });

            html += '</tbody></table></div></div>';
        });
        $('#mcp-deep-results').html(html);
    }

    /* Select all */
    $('#mcp-deep-select-all').on('change', function () {
        $('.mcp-deep-check').prop('checked', $(this).is(':checked'));
    });

    /* Delete selected */
    $('#mcp-deep-delete-selected').on('click', function () {
        var ids = $.map($('.mcp-deep-check:checked'), function (el) { return parseInt($(el).val(), 10); });
        if (!ids.length) { alert('Please select at least one copy to delete.'); return; }
        if (!confirm('Permanently delete ' + ids.length + ' selected file(s)? This cannot be undone.')) return;
        doDelete(ids);
    });

    /* Delete ALL copies */
    $('#mcp-deep-delete-all-copies').on('click', function () {
        var ids = $.map($('.mcp-deep-check:not(:disabled)'), function (el) { return parseInt($(el).val(), 10); });
        if (!ids.length) { alert('No deletable copies found.'); return; }
        if (!confirm('⚠ Permanently delete ALL ' + ids.length + ' duplicate copy file(s)? This cannot be undone!')) return;
        doDelete(ids);
    });

    /* Delete single row */
    $(document).on('click', '.mcp-del-single', function () {
        var rowId = parseInt($(this).data('row-id'), 10);
        if (!confirm('Delete this file permanently?')) return;
        doDelete([rowId]);
    });

    /* Delete all copies in one group */
    $(document).on('click', '.mcp-del-group-copies', function () {
        var gi  = $(this).data('group');
        var ids = $.map($('#mcp-group-' + gi + ' .mcp-deep-check:not(:disabled)'), function (el) { return parseInt($(el).val(), 10); });
        if (!ids.length) { alert('No deletable copies in this group.'); return; }
        if (!confirm('Delete all copies in this group? (' + ids.length + ' file(s))')) return;
        doDelete(ids);
    });

    // We reuse the #mcp-fd-spinner UI for manual deletes by making it an overlay
    var $overlay = null;

    function doDelete(rowIds) {
        if (!$overlay) {
            $overlay = $('<div style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(255,255,255,0.9);z-index:99999;display:flex;align-items:center;justify-content:center;flex-direction:column;"></div>').appendTo('body');
            $overlay.html($('#mcp-fd-spinner').html());
        }
        $overlay.fadeIn();

        var total       = rowIds.length;
        var batchSize   = 50;
        var currentBatch= 0;
        var totalBatches= Math.ceil(total / batchSize);
        var deletedCount= 0;
        var protectedCount = 0;

        function processNext() {
            var remaining = total - deletedCount - protectedCount;
            if (currentBatch > 0) {
                $overlay.find('h3').text('Moving ' + remaining + ' file(s) to trash... (' + Math.round((currentBatch/totalBatches)*100) + '%)');
            } else {
                $overlay.find('h3').text('Moving ' + remaining + ' file(s) to trash...');
            }

            if (currentBatch >= totalBatches) {
                $overlay.fadeOut();
                var msg = 'Successfully removed ' + deletedCount + ' files.';
                var noticeType = 'success';
                if (protectedCount > 0) {
                    msg += ' (' + protectedCount + ' files perfectly protected/skipped).';
                    noticeType = deletedCount === 0 ? 'error' : 'info';
                }
                notice((protectedCount > 0 ? '🔒 ' : '✅ ') + msg, noticeType);
                
                setTimeout(function () {
                    $('.mcp-deep-group').each(function () {
                        if ($(this).find('.mcp-deep-check:not(:disabled)').length === 0) {
                            $(this).fadeOut(300, function () { $(this).remove(); });
                        }
                    });
                }, 400);
                return;
            }

            var batchIds = rowIds.slice(currentBatch * batchSize, (currentBatch + 1) * batchSize);

            $.post(MCP.ajax_url, { action: 'mcp_deep_dup_delete', nonce: MCP.nonce, row_ids: batchIds })
            .done(function (res) {
                if (!res.success) {
                    $overlay.fadeOut();
                    notice(res.data.message || 'Error processing batch', 'error');
                    return;
                }
                
                var d = res.data;
                var skippedPaths = [];
                
                if (d.skipped && d.skipped.length) {
                    protectedCount += d.skipped.length;
                    d.skipped.forEach(function (sk) {
                        skippedPaths.push(sk.path);
                        $('.mcp-path').filter(function () { return $(this).text() === sk.path; })
                            .closest('tr').css({'background':'#fef9c3','outline':'2px solid #f59e0b'})
                            .find('td:last-child').html('<span style="color:#92400e;font-size:12px;">🔒 Protected: in use</span>');
                    });
                }
                
                batchIds.forEach(function (id) {
                    var $row = $('#mcp-row-' + id);
                    if (skippedPaths.indexOf($row.find('.mcp-path').text()) === -1) {
                        deletedCount++;
                        $row.fadeOut(300, function () { $(this).remove(); });
                    }
                });

                currentBatch++;
                processNext();
            })
            .fail(function (xhr) {
                $overlay.fadeOut();
                ajaxErr(xhr, 'delete batch');
            });
        }

        processNext();
    }

    /* ── Helpers ─────────────────────────────────────────────────────────── */
    function setBtn(busy) {
        var $btn = $('#mcp-deep-scan-btn');
        $btn.prop('disabled', busy);
        $btn.find('.dashicons').toggleClass('spin', busy);
    }
    function progShow()  { $('#mcp-deep-progress').show(); $('#mcp-person-scan-anim').slideDown(200); }
    function progHide()  { setTimeout(function () { $('#mcp-deep-progress').fadeOut(); $('#mcp-person-scan-anim').slideUp(300); }, 1000); }
    function progUpdate(done) {
        var pct = scanTotal > 0 ? Math.min(100, Math.round(done / scanTotal * 100)) : 0;
        $('#mcp-deep-fill').css('width', pct + '%');
        $('#mcp-deep-text').text(pct + '% — ' + done + ' / ' + scanTotal + ' files hashed');
    }
    function notice(msg, type) {
        $('#mcp-deep-notice')
            .removeClass('mcp-notice--success mcp-notice--error mcp-notice--info')
            .addClass('mcp-notice--' + type).html(msg).show();
    }
    function esc(str) { return $('<div>').text(String(str || '')).html(); }
    function ajaxErr(xhr, stage) {
        var detail = '';
        if (xhr.responseText) {
            detail = ': ' + $('<div>').html(xhr.responseText).text().substring(0, 180);
        }
        notice('❌ AJAX error during ' + stage + detail, 'error');
    }
});
</script>
