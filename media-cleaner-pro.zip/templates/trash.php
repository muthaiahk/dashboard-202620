<?php
/**
 * Template: Trash Manager
 *
 * @package Media Cleaner Pro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;
$trash_table = \MCP\DB\Schema::table( 'trash' );

$page     = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
$per_page = 20;
$offset   = ( $page - 1 ) * $per_page;

$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trash_table}" );
$rows  = $wpdb->get_results( $wpdb->prepare(
    "SELECT t.attachment_id, t.original_path, t.trashed_at, u.display_name
     FROM {$trash_table} t
     LEFT JOIN {$wpdb->users} u ON u.ID = t.trashed_by
     ORDER BY t.trashed_at DESC
     LIMIT %d OFFSET %d",
    $per_page,
    $offset
) );

$total_pages = (int) ceil( $total / $per_page );
?>
<div class="wrap mcp-wrap">

    <div class="mcp-header">
        <div class="mcp-header__logo">
            <span class="dashicons dashicons-archive"></span>
            <div>
                <h1><?php esc_html_e( 'Media Trash', 'media-cleaner-pro' ); ?></h1>
                <p><?php printf(
                    /* translators: %d: number of items in trash */
                    esc_html__( '%d item(s) in trash.', 'media-cleaner-pro' ),
                    $total
                ); ?></p>
            </div>
        </div>
    </div>

    <div id="mcp-trash-notice" class="mcp-notice" style="display:none;"></div>

    <?php if ( $rows ) : ?>

    <div class="mcp-toolbar">
        <label>
            <input type="checkbox" id="mcp-trash-select-all">
            <?php esc_html_e( 'Select All', 'media-cleaner-pro' ); ?>
        </label>
        <button id="mcp-trash-restore-bulk" class="button mcp-btn-icon">
            <span class="dashicons dashicons-undo"></span>
            <?php esc_html_e( 'Restore Selected', 'media-cleaner-pro' ); ?>
        </button>
        <button id="mcp-trash-delete-bulk" class="button mcp-btn-icon mcp-btn-danger">
            <span class="dashicons dashicons-dismiss"></span>
            <?php esc_html_e( 'Delete Permanently', 'media-cleaner-pro' ); ?>
        </button>
    </div>

    <table class="mcp-table widefat">
        <thead>
            <tr>
                <th width="30"></th>
                <th width="60"><?php esc_html_e( 'Preview',    'media-cleaner-pro' ); ?></th>
                <th><?php esc_html_e( 'File Path',             'media-cleaner-pro' ); ?></th>
                <th><?php esc_html_e( 'Trashed By',            'media-cleaner-pro' ); ?></th>
                <th><?php esc_html_e( 'Trashed At',            'media-cleaner-pro' ); ?></th>
                <th><?php esc_html_e( 'Actions',               'media-cleaner-pro' ); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $rows as $row ) :
            $id    = (int) $row->attachment_id;
            $thumb = wp_get_attachment_image_url( $id, 'thumbnail' );
        ?>
            <tr data-id="<?php echo esc_attr( $id ); ?>">
                <td><input type="checkbox" class="mcp-trash-check" value="<?php echo esc_attr( $id ); ?>"></td>
                <td>
                    <?php if ( $thumb ) : ?>
                        <img src="<?php echo esc_url( $thumb ); ?>" width="50" height="50" style="object-fit:cover;border-radius:4px;">
                    <?php else : ?>
                        <span class="dashicons dashicons-media-default" style="font-size:36px;"></span>
                    <?php endif; ?>
                </td>
                <td><code><?php echo esc_html( wp_basename( $row->original_path ) ); ?></code></td>
                <td><?php echo esc_html( $row->display_name ?? __( 'Unknown', 'media-cleaner-pro' ) ); ?></td>
                <td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' H:i', strtotime( $row->trashed_at ) ) ); ?></td>
                <td class="mcp-row-actions">
                    <button class="button mcp-btn-sm mcp-trash-restore" data-id="<?php echo esc_attr( $id ); ?>">
                        <span class="dashicons dashicons-undo"></span> <?php esc_html_e( 'Restore', 'media-cleaner-pro' ); ?>
                    </button>
                    <button class="button mcp-btn-sm mcp-btn-danger mcp-trash-delete" data-id="<?php echo esc_attr( $id ); ?>">
                        <span class="dashicons dashicons-dismiss"></span> <?php esc_html_e( 'Delete', 'media-cleaner-pro' ); ?>
                    </button>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- ── Pagination ─────────────────────────────────────────────────────── -->
    <?php if ( $total_pages > 1 ) : ?>
    <div class="mcp-pagination tablenav">
        <div class="tablenav-pages">
            <?php
            echo paginate_links( [
                'base'      => add_query_arg( 'paged', '%#%' ),
                'format'    => '',
                'current'   => $page,
                'total'     => $total_pages,
                'prev_text' => '&laquo;',
                'next_text' => '&raquo;',
            ] );
            ?>
        </div>
    </div>
    <?php endif; ?>

    <?php else : ?>
        <p class="mcp-empty"><?php esc_html_e( 'The trash is empty.', 'media-cleaner-pro' ); ?></p>
    <?php endif; ?>

</div>

<script>
jQuery(function ($) {

    $('#mcp-trash-select-all').on('change', function () {
        $('.mcp-trash-check').prop('checked', $(this).is(':checked'));
    });

    // Bulk restore
    $('#mcp-trash-restore-bulk').on('click', function () {
        var ids = getChecked();
        if (!ids.length) { alert(MCP.i18n.select_one); return; }
        doRestore(ids, null);
    });

    // Bulk delete
    $('#mcp-trash-delete-bulk').on('click', function () {
        var ids = getChecked();
        if (!ids.length) { alert(MCP.i18n.select_one); return; }
        if (!confirm(MCP.i18n.confirm_delete)) return;
        doDelete(ids, null);
    });

    // Single restore
    $(document).on('click', '.mcp-trash-restore', function () {
        doRestore([$(this).data('id')], $(this).closest('tr'));
    });

    // Single delete
    $(document).on('click', '.mcp-trash-delete', function () {
        if (!confirm(MCP.i18n.confirm_delete)) return;
        doDelete([$(this).data('id')], $(this).closest('tr'));
    });

    function getChecked() {
        return $.map($('.mcp-trash-check:checked'), function (el) { return parseInt($(el).val()); });
    }

    function doRestore(ids, row) {
        notice(MCP.i18n.restoring, 'info');
        $.post(MCP.ajax_url, { action: 'mcp_restore', nonce: MCP.nonce, ids: ids })
            .done(function (res) {
                notice(res.data.message, res.success ? 'success' : 'error');
                if (res.success) removeRows(ids, row);
            });
    }

    function doDelete(ids, row) {
        notice(MCP.i18n.deleting, 'info');
        $.post(MCP.ajax_url, { action: 'mcp_delete', nonce: MCP.nonce, ids: ids })
            .done(function (res) {
                notice(res.data.message, res.success ? 'success' : 'error');
                if (res.success) removeRows(ids, row);
            });
    }

    function removeRows(ids, row) {
        if (row) { row.fadeOut(300, function () { row.remove(); }); return; }
        ids.forEach(function (id) {
            $('tr[data-id="' + id + '"]').fadeOut(300, function () { $(this).remove(); });
        });
    }

    function notice(msg, type) {
        $('#mcp-trash-notice')
            .removeClass('mcp-notice--success mcp-notice--error mcp-notice--info')
            .addClass('mcp-notice--' + type).html(msg).show();
    }
});
</script>
