<?php
namespace MCP\Ajax;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once MCP_INCLUDES . 'Ajax/trait-ajax.php';

/**
 * Permanent delete handler — bulk, with scan-cache cleanup.
 */
final class Delete {

    use AjaxTrait;

    public function __construct() {
        add_action( 'wp_ajax_mcp_delete', [ $this, 'handle' ] );
    }

    public function handle(): void {
        $this->verify();

        $ids = $this->array_param( 'ids' );
        if ( empty( $ids ) ) {
            wp_send_json_error( [ 'message' => __( 'No IDs provided.', 'media-cleaner-pro' ) ] );
        }

        $deleted  = 0;
        $freed    = 0;
        $errors   = [];

        global $wpdb;

        foreach ( $ids as $id ) {
            $path = get_attached_file( $id );
            $size = ( $path && file_exists( $path ) ) ? filesize( $path ) : 0;

            $result = wp_delete_attachment( $id, true );

            if ( $result ) {
                $deleted++;
                $freed += $size;

                // Remove from scan cache
                $wpdb->delete(
                    \MCP\DB\Schema::table( 'scan_results' ),
                    [ 'attachment_id' => $id ],
                    [ '%d' ]
                );

                // Remove from trash log if present
                $wpdb->delete(
                    \MCP\DB\Schema::table( 'trash' ),
                    [ 'attachment_id' => $id ],
                    [ '%d' ]
                );
            } else {
                $errors[] = $id;
            }
        }

        wp_send_json_success( [
            'deleted' => $deleted,
            'freed'   => $freed,
            'freed_hr'=> size_format( $freed, 2 ),
            'errors'  => $errors,
            'message' => sprintf(
                /* translators: 1: count deleted, 2: space freed */
                __( '%1$d item(s) permanently deleted. %2$s freed.', 'media-cleaner-pro' ),
                $deleted,
                size_format( $freed, 2 )
            ),
        ] );
    }
}
