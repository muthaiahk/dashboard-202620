<?php
namespace MCP\Ajax;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once MCP_INCLUDES . 'Ajax/trait-ajax.php';

/**
 * Stats handler — returns dashboard counts for the overview widgets.
 */
final class Stats {

    use AjaxTrait;

    public function __construct() {
        add_action( 'wp_ajax_mcp_stats', [ $this, 'handle' ] );
    }

    public function handle(): void {
        $this->verify();

        global $wpdb;

        $table = \MCP\DB\Schema::table( 'scan_results' );
        $trash = \MCP\DB\Schema::table( 'trash' );

        $total_attachments = (int) $wpdb->get_var(
            "SELECT COUNT(ID) FROM {$wpdb->posts}
             WHERE post_type = 'attachment' AND post_status = 'inherit'"
        );

        $unused_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE scan_type = 'unused'"
        );

        $unused_size = (int) $wpdb->get_var(
            "SELECT SUM(file_size) FROM {$table} WHERE scan_type = 'unused'"
        );

        $large_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$table} WHERE scan_type = 'large'"
        );

        $large_size = (int) $wpdb->get_var(
            "SELECT SUM(file_size) FROM {$table} WHERE scan_type = 'large'"
        );

        $fs_dups = \MCP\DB\Schema::table( 'fs_duplicates' );
        $dup_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM (
                SELECT hash FROM {$fs_dups}
                WHERE hash IS NOT NULL
                GROUP BY hash HAVING COUNT(*) > 1
             ) AS dup_hashes"
        );

        $trash_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$trash}" );

        $last_scan = $wpdb->get_var( "SELECT MAX(scanned_at) FROM {$table}" );

        wp_send_json_success( [
            'total_attachments' => $total_attachments,
            'unused'            => [ 'count' => $unused_count, 'size' => size_format( (int) $unused_size, 2 ) ],
            'large'             => [ 'count' => $large_count,  'size' => size_format( (int) $large_size,  2 ) ],
            'duplicate_groups'  => $dup_count,
            'trash_count'       => $trash_count,
            'last_scan'         => $last_scan ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $last_scan ) ) : __( 'Never', 'media-cleaner-pro' ),
        ] );
    }
}
