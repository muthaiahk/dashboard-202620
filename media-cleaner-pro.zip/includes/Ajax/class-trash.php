<?php
namespace MCP\Ajax;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once MCP_INCLUDES . 'Ajax/trait-ajax.php';

/**
 * Handles soft-delete (Trash) and restore operations.
 */
final class Trash {

    use AjaxTrait;

    public function __construct() {
        add_action( 'wp_ajax_mcp_trash',   [ $this, 'handle_trash' ] );
        add_action( 'wp_ajax_mcp_restore', [ $this, 'handle_restore' ] );
    }

    // ── Move to trash ─────────────────────────────────────────────────────────
    public function handle_trash(): void {
        $this->verify();

        $ids = $this->array_param( 'ids' );
        if ( empty( $ids ) ) {
            wp_send_json_error( [ 'message' => __( 'No IDs provided.', 'media-cleaner-pro' ) ] );
        }

        $trashed = 0;
        $errors  = [];

        global $wpdb;

        foreach ( $ids as $id ) {
            $path = get_attached_file( $id );

            if ( ! $path || ! file_exists( $path ) ) {
                $errors[] = $id;
                continue;
            }

            // Insert into trash log
            $result = $wpdb->replace(
                \MCP\DB\Schema::table( 'trash' ),
                [
                    'attachment_id' => $id,
                    'original_path' => $path,
                    'trashed_by'    => get_current_user_id(),
                    'trashed_at'    => current_time( 'mysql' ),
                ],
                [ '%d', '%s', '%d', '%s' ]
            );

            if ( false === $result ) {
                $errors[] = $id;
                continue;
            }

            // Mark attachment meta
            update_post_meta( $id, MCP_TRASH_META, '1' );

            // Soft-delete: wp_trash_post keeps the DB record but marks it
            wp_trash_post( $id );

            $trashed++;
        }

        wp_send_json_success( [
            'trashed' => $trashed,
            'errors'  => $errors,
            'message' => sprintf(
                /* translators: %d: number of items trashed */
                _n( '%d item moved to trash.', '%d items moved to trash.', $trashed, 'media-cleaner-pro' ),
                $trashed
            ),
        ] );
    }

    // ── Restore from trash ────────────────────────────────────────────────────
    public function handle_restore(): void {
        $this->verify();

        $ids = $this->array_param( 'ids' );
        if ( empty( $ids ) ) {
            wp_send_json_error( [ 'message' => __( 'No IDs provided.', 'media-cleaner-pro' ) ] );
        }

        $restored = 0;
        $errors   = [];

        global $wpdb;

        foreach ( $ids as $id ) {
            $result = wp_untrash_post( $id );

            if ( $result ) {
                delete_post_meta( $id, MCP_TRASH_META );
                $wpdb->delete(
                    \MCP\DB\Schema::table( 'trash' ),
                    [ 'attachment_id' => $id ],
                    [ '%d' ]
                );
                $restored++;
            } else {
                $errors[] = $id;
            }
        }

        wp_send_json_success( [
            'restored' => $restored,
            'errors'   => $errors,
            'message'  => sprintf(
                /* translators: %d: number of items restored */
                _n( '%d item restored.', '%d items restored.', $restored, 'media-cleaner-pro' ),
                $restored
            ),
        ] );
    }
}
