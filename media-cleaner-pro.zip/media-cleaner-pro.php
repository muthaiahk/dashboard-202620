<?php
/**
 * Plugin Name:       Media Cleaner Pro
 * Plugin URI:        https://example.com/media-cleaner-pro
 * Description:       Professional WordPress media management: AJAX batch scan, unused media detection, duplicate finder, WebP compression, and safe trash mode.
 * Version:           2.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            Your Name
 * Author URI:        https://example.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       media-cleaner-pro
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ─── Constants ────────────────────────────────────────────────────────────────
define( 'MCP_VERSION',   '2.0.0' );
define( 'MCP_PLUGIN_FILE', __FILE__ );
define( 'MCP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MCP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'MCP_INCLUDES',  MCP_PLUGIN_DIR . 'includes/' );
define( 'MCP_ASSETS',    MCP_PLUGIN_URL . 'assets/' );
define( 'MCP_BATCH_SIZE', 50 );         // items per AJAX batch
define( 'MCP_WEBP_QUALITY', 82 );       // WebP quality 0-100
define( 'MCP_TRASH_META', '_mcp_trashed' );

// ─── Autoloader ───────────────────────────────────────────────────────────────
spl_autoload_register( function ( $class ) {
    $prefix = 'MCP\\';
    $base   = MCP_INCLUDES;

    if ( strncmp( $prefix, $class, strlen( $prefix ) ) !== 0 ) {
        return;
    }

    // Strip top-level namespace prefix: MCP\Ajax\Scan → Ajax\Scan
    $relative = substr( $class, strlen( $prefix ) );
    $parts    = explode( '\\', $relative );

    if ( count( $parts ) === 1 ) {
        // Top-level class: MCP\Plugin → includes/class-plugin.php
        $file = $base . 'class-' . strtolower( $parts[0] ) . '.php';
    } else {
        // Namespaced class: MCP\Ajax\Scan → includes/Ajax/class-scan.php
        $subdir    = implode( '/', array_slice( $parts, 0, -1 ) ); // e.g. Ajax
        $classname = end( $parts );                                 // e.g. Scan
        $file      = $base . $subdir . '/class-' . strtolower( $classname ) . '.php';
    }

    if ( file_exists( $file ) ) {
        require $file;
    }
} );

// ─── Bootstrap ────────────────────────────────────────────────────────────────
require_once MCP_INCLUDES . 'class-plugin.php';

\MCP\Plugin::get_instance()->init();