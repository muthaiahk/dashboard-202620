<?php
/**
 * Template: Dashboard overview
 *
 * @package Media Cleaner Pro
 */
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="wrap mcp-wrap">

    <div class="mcp-header">
        <div class="mcp-header__logo">
            <span class="dashicons dashicons-editor-removeformatting"></span>
            <div>
                <h1><?php esc_html_e( 'Media Cleaner Pro', 'media-cleaner-pro' ); ?></h1>
                <p><?php printf(
                    /* translators: %s: plugin version */
                    esc_html__( 'Version %s — Professional WordPress Media Management', 'media-cleaner-pro' ),
                    esc_html( MCP_VERSION )
                ); ?></p>
            </div>
        </div>
    </div>

    <!-- ── Stat widgets ──────────────────────────────────────────────────── -->
    <div class="mcp-stats-grid" id="mcp-stats-grid">
        <?php $widgets = [
            [ 'id' => 'stat-total',   'icon' => 'dashicons-images-alt2', 'label' => __( 'Total Attachments',  'media-cleaner-pro' ) ],
            [ 'id' => 'stat-unused',  'icon' => 'dashicons-trash',        'label' => __( 'Unused Files',       'media-cleaner-pro' ) ],
            [ 'id' => 'stat-large',   'icon' => 'dashicons-chart-bar',    'label' => __( 'Large Files (>5MB)', 'media-cleaner-pro' ) ],
            [ 'id' => 'stat-dups',    'icon' => 'dashicons-admin-page',   'label' => __( 'Duplicate Groups',  'media-cleaner-pro' ) ],
            [ 'id' => 'stat-trash',   'icon' => 'dashicons-archive',      'label' => __( 'Items in Trash',    'media-cleaner-pro' ) ],
        ];
        foreach ( $widgets as $w ) : ?>
            <div class="mcp-stat-card" id="<?php echo esc_attr( $w['id'] ); ?>">
                <span class="dashicons <?php echo esc_attr( $w['icon'] ); ?>"></span>
                <div class="mcp-stat-card__value">—</div>
                <div class="mcp-stat-card__label"><?php echo esc_html( $w['label'] ); ?></div>
            </div>
        <?php endforeach; ?>
    </div>

    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
        <p class="mcp-last-scan" style="margin:0;">
            <?php esc_html_e( 'Last DB metrics update:', 'media-cleaner-pro' ); ?>
            <strong id="mcp-last-scan-date">—</strong>
        </p>
        <div style="display:flex;align-items:center;gap:15px;">
            <span style="font-size:12px;color:#8c8f94;">
                <span class="dashicons dashicons-info-outline" style="font-size:16px;line-height:1;margin-top:2px;"></span>
                Run the specific scanners below to find Unused or Duplicate files before refreshing.
            </span>
            <button id="mcp-refresh-stats" class="button mcp-btn-icon">
                <span class="dashicons dashicons-update"></span>
                <?php esc_html_e( 'Refresh Data', 'media-cleaner-pro' ); ?>
            </button>
        </div>
    </div>

    <!-- ── Quick action cards ─────────────────────────────────────────────── -->
    <div class="mcp-action-grid">

        <div class="mcp-action-card">
            <span class="dashicons dashicons-search"></span>
            <h3><?php esc_html_e( 'Scan Unused Media', 'media-cleaner-pro' ); ?></h3>
            <p><?php esc_html_e( 'Find attachments not referenced in any post, page, or page builder.', 'media-cleaner-pro' ); ?></p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mcp-unused' ) ); ?>" class="button button-primary">
                <?php esc_html_e( 'Go to Scanner', 'media-cleaner-pro' ); ?>
            </a>
        </div>

        <div class="mcp-action-card">
            <span class="dashicons dashicons-admin-page"></span>
            <h3><?php esc_html_e( 'Find Duplicates', 'media-cleaner-pro' ); ?></h3>
            <p><?php esc_html_e( 'Detect identical images by MD5 hash and remove redundant copies.', 'media-cleaner-pro' ); ?></p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mcp-duplicates' ) ); ?>" class="button button-primary">
                <?php esc_html_e( 'Find Duplicates', 'media-cleaner-pro' ); ?>
            </a>
        </div>

        <div class="mcp-action-card">
            <span class="dashicons dashicons-images-alt"></span>
            <h3><?php esc_html_e( 'WebP Compression', 'media-cleaner-pro' ); ?></h3>
            <p><?php esc_html_e( 'Convert JPEG/PNG/GIF images to WebP format for significant size savings.', 'media-cleaner-pro' ); ?></p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mcp-webp' ) ); ?>" class="button button-primary">
                <?php esc_html_e( 'Compress Images', 'media-cleaner-pro' ); ?>
            </a>
        </div>

        <div class="mcp-action-card">
            <span class="dashicons dashicons-archive"></span>
            <h3><?php esc_html_e( 'Trash & Restore', 'media-cleaner-pro' ); ?></h3>
            <p><?php esc_html_e( 'Review soft-deleted media and restore or permanently remove them.', 'media-cleaner-pro' ); ?></p>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mcp-trash' ) ); ?>" class="button button-primary">
                <?php esc_html_e( 'View Trash', 'media-cleaner-pro' ); ?>
            </a>
        </div>

    </div>

</div>

<script>
jQuery(function($){
    function loadStats() {
        var $btn = $('#mcp-refresh-stats');
        var $icon = $btn.find('.dashicons');
        $btn.prop('disabled', true);
        $icon.addClass('spin');

        $.post(MCP.ajax_url, { action: 'mcp_stats', nonce: MCP.nonce }, function(res){
            $btn.prop('disabled', false);
            $icon.removeClass('spin');
            
            if (!res.success) return;
            var d = res.data;
            $('#stat-total   .mcp-stat-card__value').text(d.total_attachments);
            $('#stat-unused  .mcp-stat-card__value').text(d.unused.count + ' (' + d.unused.size + ')');
            $('#stat-large   .mcp-stat-card__value').text(d.large.count  + ' (' + d.large.size  + ')');
            $('#stat-dups    .mcp-stat-card__value').text(d.duplicate_groups);
            $('#stat-trash   .mcp-stat-card__value').text(d.trash_count);
            $('#mcp-last-scan-date').text(d.last_scan);
        }).fail(function() {
            $btn.prop('disabled', false);
            $icon.removeClass('spin');
        });
    }

    // Auto-load on init
    loadStats();

    // Reload on click
    $('#mcp-refresh-stats').on('click', loadStats);
});
</script>
