<?php
namespace MCP;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Core Plugin class — singleton that wires up every sub-system.
 */
final class Plugin {

    private static ?Plugin $instance = null;

    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    public function init(): void {
        // i18n
        add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );

        // Auto-upgrade DB schema if plugin version changed
        add_action( 'plugins_loaded', [ $this, 'maybe_upgrade_db' ] );

        // Activation / deactivation hooks
        register_activation_hook(   MCP_PLUGIN_FILE, [ 'MCP\DB\Schema', 'install' ] );
        register_deactivation_hook( MCP_PLUGIN_FILE, [ 'MCP\DB\Schema', 'deactivate' ] );

        // Admin UI
        if ( is_admin() ) {
            new Admin\Menu();
            new Admin\Assets();
        }

        // AJAX handlers (admin + nopriv is deliberately excluded — auth required)
        new Ajax\Scan();
        new Ajax\Trash();
        new Ajax\Delete();
        new Ajax\Duplicates();
        new Ajax\Webp();
        new Ajax\Stats();
    }

    public function maybe_upgrade_db(): void {
        if ( get_option( 'mcp_db_version' ) !== MCP_VERSION ) {
            \MCP\DB\Schema::install();
        }
    }

    public function load_textdomain(): void {
        load_plugin_textdomain(
            'media-cleaner-pro',
            false,
            dirname( plugin_basename( MCP_PLUGIN_FILE ) ) . '/languages'
        );
    }
}
