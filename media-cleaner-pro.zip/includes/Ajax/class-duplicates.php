<?php
namespace MCP\Ajax;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once MCP_INCLUDES . 'Ajax/trait-ajax.php';

/**
 * Deep Duplicate Finder — walks the entire uploads/ directory on disk.
 *
 * Unlike the basic scanner (which only queries wp_posts), this handler:
 *  1. Recursively lists EVERY file in wp-content/uploads/
 *  2. Computes MD5 hash of each file (batched to avoid timeouts)
 *  3. Cross-references with WP media library to flag orphan files
 *  4. Groups files by hash — any hash appearing 2+ times is a duplicate set
 *  5. Lets the admin bulk-delete copies (supports both WP attachments & orphans)
 *
 * AJAX Flow:
 *  mcp_deep_dup_start  → builds file index, returns {total}
 *  mcp_deep_dup_batch  → hashes a slice of files, returns {processed, done}
 *  mcp_deep_dup_groups → returns grouped duplicates from mcp_fs_duplicates
 *  mcp_deep_dup_delete → permanently removes selected files (by row ID)
 *
 * Legacy flow (wp_posts based) still available on mcp_dup_* actions.
 */
final class Duplicates {

    use AjaxTrait;

    /** Transient key for the file index built during start */
    private const INDEX_TRANSIENT = 'mcp_deep_scan_index';

    /** Supported file extensions to hash */
    private const EXTENSIONS = [
        'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg',
        'pdf', 'mp4', 'mov', 'avi', 'mp3', 'wav',
        'zip', 'tar', 'gz',
        'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
    ];

    public function __construct() {
        // ── Legacy WP media-library-only flow ─────────────────────────────────
        add_action( 'wp_ajax_mcp_dup_start',  [ $this, 'handle_start' ] );
        add_action( 'wp_ajax_mcp_dup_batch',  [ $this, 'handle_batch' ] );
        add_action( 'wp_ajax_mcp_dup_groups', [ $this, 'handle_groups' ] );

        // ── Deep filesystem flow ───────────────────────────────────────────────
        add_action( 'wp_ajax_mcp_deep_dup_start',       [ $this, 'deep_start' ] );
        add_action( 'wp_ajax_mcp_deep_dup_batch',       [ $this, 'deep_batch' ] );
        add_action( 'wp_ajax_mcp_deep_dup_groups',      [ $this, 'deep_groups' ] );
        add_action( 'wp_ajax_mcp_deep_dup_delete',      [ $this, 'deep_delete' ] );

        // ── One-click Find & Delete ───────────────────────────────────────────
        add_action( 'wp_ajax_mcp_deep_dup_find_delete', [ $this, 'deep_find_delete' ] );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // LEGACY: WP media-library only (mcp_dup_*)
    // ══════════════════════════════════════════════════════════════════════════

    public function handle_start(): void {
        $this->verify();
        global $wpdb;
        $wpdb->delete( \MCP\DB\Schema::table( 'scan_results' ), [ 'scan_type' => 'duplicate' ], [ '%s' ] );
        $total = (int) $wpdb->get_var(
            "SELECT COUNT(ID) FROM {$wpdb->posts}
             WHERE post_type = 'attachment'
               AND post_status = 'inherit'
               AND post_mime_type IN ('image/jpeg','image/png','image/gif','image/webp')"
        );
        wp_send_json_success( [ 'total' => $total ] );
    }

    public function handle_batch(): void {
        $this->verify();
        $offset = $this->int_param( 'offset', 0 );
        $total  = $this->int_param( 'total', 0 );
        global $wpdb;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type = 'attachment'
               AND post_status = 'inherit'
               AND post_mime_type IN ('image/jpeg','image/png','image/gif','image/webp')
             ORDER BY ID ASC
             LIMIT %d OFFSET %d",
            MCP_BATCH_SIZE,
            $offset
        ) );

        foreach ( $rows as $row ) {
            $id   = (int) $row->ID;
            $path = get_attached_file( $id );
            if ( ! $path || ! file_exists( $path ) ) continue;
            $hash = md5_file( $path );
            $size = filesize( $path );
            $wpdb->replace(
                \MCP\DB\Schema::table( 'scan_results' ),
                [ 'scan_type' => 'duplicate', 'attachment_id' => $id, 'file_path' => $path, 'file_size' => $size, 'hash' => $hash, 'scanned_at' => current_time( 'mysql' ) ],
                [ '%s', '%d', '%s', '%d', '%s', '%s' ]
            );
        }

        $processed = $offset + count( $rows );
        $done      = $processed >= $total || count( $rows ) === 0;
        wp_send_json_success( [ 'processed' => $processed, 'done' => $done ] );
    }

    public function handle_groups(): void {
        $this->verify();
        global $wpdb;
        $table  = \MCP\DB\Schema::table( 'scan_results' );
        $hashes = $wpdb->get_col(
            "SELECT hash FROM {$table} WHERE scan_type = 'duplicate' AND hash IS NOT NULL GROUP BY hash HAVING COUNT(*) > 1"
        );
        if ( empty( $hashes ) ) { wp_send_json_success( [ 'groups' => [] ] ); }
        $placeholders = implode( ',', array_fill( 0, count( $hashes ), '%s' ) );
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT attachment_id, file_path, file_size, hash FROM {$table} WHERE scan_type = 'duplicate' AND hash IN ($placeholders) ORDER BY hash, attachment_id ASC",
                ...$hashes
            )
        );
        $groups = [];
        foreach ( $rows as $row ) {
            $id = (int) $row->attachment_id;
            if ( ! isset( $groups[ $row->hash ] ) ) $groups[ $row->hash ] = [];
            $groups[ $row->hash ][] = [
                'id' => $id, 'title' => get_the_title( $id ),
                'url' => wp_get_attachment_url( $id ),
                'thumb' => wp_get_attachment_image_url( $id, 'thumbnail' ),
                'size' => (int) $row->file_size, 'size_hr' => size_format( (int) $row->file_size, 2 ),
            ];
        }
        wp_send_json_success( [ 'groups' => array_values( $groups ) ] );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // DEEP SCAN: full uploads/ filesystem walk (mcp_deep_dup_*)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Step 1 — Index all files in uploads/ and store the list in a transient.
     * Returns {total} number of files to hash.
     */
    public function deep_start(): void {
        $this->verify();

        global $wpdb;

        try {
            // Ensure the mcp_fs_duplicates table exists (auto-creates if DB not yet upgraded)
            $table = \MCP\DB\Schema::table( 'fs_duplicates' );
            $exists = $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" );
            if ( ! $exists ) {
                \MCP\DB\Schema::install();
            }

            // Wipe previous deep-scan results (DELETE is safer than TRUNCATE for low-privilege users)
            $wpdb->query( "DELETE FROM {$table}" );

            $uploads_dir = wp_upload_dir()['basedir'];

            if ( ! is_dir( $uploads_dir ) ) {
                wp_send_json_error( [ 'message' => __( 'Uploads directory not found.', 'media-cleaner-pro' ) ] );
                return; // ← MUST return; wp_send_json_error does not exit by itself in all WP versions
            }

            // Recursive file index — paths only, keep memory lean
            $files = $this->index_files( $uploads_dir );

            if ( empty( $files ) ) {
                wp_send_json_success( [ 'total' => 0 ] );
                return;
            }

            // Store index in transient (serialized array of absolute paths)
            set_transient( self::INDEX_TRANSIENT, $files, 2 * HOUR_IN_SECONDS );

            wp_send_json_success( [ 'total' => count( $files ) ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [
                'message' => __( 'Scan failed: ', 'media-cleaner-pro' ) . $e->getMessage(),
            ] );
        }
    }

    /**
     * Step 2 — Hash a batch of files and insert into mcp_fs_duplicates.
     * Expects POST: offset, total
     */
    public function deep_batch(): void {
        $this->verify();

        $offset = $this->int_param( 'offset', 0 );
        $total  = $this->int_param( 'total', 0 );

        $files  = get_transient( self::INDEX_TRANSIENT );
        if ( ! is_array( $files ) ) {
            wp_send_json_error( [ 'message' => __( 'Scan index expired. Please restart the scan.', 'media-cleaner-pro' ) ] );
            return;
        }

        // Build a path→attachment_id map for this batch only (memory efficient)
        $batch = array_slice( $files, $offset, MCP_BATCH_SIZE );

        if ( empty( $batch ) ) {
            wp_send_json_success( [ 'processed' => $total, 'done' => true ] );
            return;
        }

        $attachment_map = $this->build_attachment_map( $batch );

        global $wpdb;
        $table = \MCP\DB\Schema::table( 'fs_duplicates' );

        $rows = [];
        foreach ( $batch as $path ) {
            if ( ! file_exists( $path ) ) continue;
            $hash          = md5_file( $path );
            $size          = filesize( $path );
            $attachment_id = $attachment_map[ $path ] ?? null;

            $rows[] = $wpdb->prepare(
                "(%s, %d, %s, " . ( $attachment_id !== null ? '%d' : 'NULL' ) . ", %s)",
                ...( $attachment_id !== null
                    ? [ $path, $size, $hash, $attachment_id, current_time( 'mysql' ) ]
                    : [ $path, $size, $hash, current_time( 'mysql' ) ]
                )
            );
        }

        if ( ! empty( $rows ) ) {
            $wpdb->query(
                "INSERT INTO {$table} (file_path, file_size, hash, attachment_id, scanned_at) VALUES " .
                implode( ',', $rows )
            );
        }

        $processed = $offset + count( $batch );
        $done      = $processed >= $total;

        wp_send_json_success( [ 'processed' => $processed, 'done' => $done ] );
    }

    /**
     * Step 3 — Return groups of duplicate files from mcp_fs_duplicates.
     */
    public function deep_groups(): void {
        $this->verify();

        global $wpdb;
        $table = \MCP\DB\Schema::table( 'fs_duplicates' );

        // Hashes that appear more than once
        $hashes = $wpdb->get_col(
            "SELECT hash FROM {$table} GROUP BY hash HAVING COUNT(*) > 1 ORDER BY COUNT(*) DESC"
        );

        if ( empty( $hashes ) ) {
            wp_send_json_success( [ 'groups' => [], 'total_files' => 0, 'total_saved' => '0 B' ] );
            return;
        }

        $placeholders = implode( ',', array_fill( 0, count( $hashes ), '%s' ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, file_path, file_size, hash, attachment_id
                 FROM {$table}
                 WHERE hash IN ($placeholders)
                 ORDER BY hash, id ASC",
                ...$hashes
            )
        );

        $groups      = [];
        $total_saved = 0;

        // Pre-build uploads URL base for orphan URL resolution
        $uploads       = wp_upload_dir();
        $uploads_base  = trailingslashit( $uploads['basedir'] );
        $uploads_url   = trailingslashit( $uploads['baseurl'] );

        foreach ( $rows as $row ) {
            $h = $row->hash;
            if ( ! isset( $groups[ $h ] ) ) $groups[ $h ] = [];

            $is_orphan     = ( $row->attachment_id === null );
            $attachment_id = $row->attachment_id ? (int) $row->attachment_id : null;

            // Resolve the public URL — needed for in-use check on orphans
            if ( $attachment_id ) {
                $file_url = wp_get_attachment_url( $attachment_id ) ?: '';
            } else {
                // Convert absolute disk path → public URL
                $rel      = str_replace( '\\', '/', $row->file_path );
                $rel      = str_replace( str_replace( '\\', '/', $uploads_base ), '', $rel );
                $file_url = $uploads_url . ltrim( $rel, '/' );
            }

            $in_use = $this->is_file_in_use( $file_url, $row->file_path, $attachment_id );

            $entry = [
                'row_id'        => (int) $row->id,
                'file_path'     => $row->file_path,
                'file_name'     => basename( $row->file_path ),
                'file_size'     => (int) $row->file_size,
                'size_hr'       => size_format( (int) $row->file_size, 2 ),
                'hash'          => $h,
                'is_orphan'     => $is_orphan,
                'in_use'        => $in_use,
                'attachment_id' => $attachment_id,
                'title'         => $attachment_id ? get_the_title( $attachment_id ) : basename( $row->file_path ),
                'url'           => $file_url,
                'thumb'         => $attachment_id ? wp_get_attachment_image_url( $attachment_id, 'thumbnail' ) : '',
            ];

            $groups[ $h ][] = $entry;
        }

        // Calculate wasted space: all copies except the first (original)
        foreach ( $groups as $h => $items ) {
            for ( $i = 1; $i < count( $items ); $i++ ) {
                $total_saved += $items[ $i ]['file_size'];
            }
        }

        wp_send_json_success( [
            'groups'      => array_values( $groups ),
            'total_files' => count( $rows ),
            'total_saved' => size_format( $total_saved, 2 ),
        ] );
    }

    /**
     * Delete duplicate files by their row IDs in mcp_fs_duplicates.
     * Supports both WP attachments (wp_delete_attachment) and orphan raw files (unlink).
     * Expects POST: row_ids[] (array of mcp_fs_duplicates.id)
     */
    public function deep_delete(): void {
        $this->verify();

        $row_ids = isset( $_POST['row_ids'] ) && is_array( $_POST['row_ids'] )
            ? array_map( 'absint', $_POST['row_ids'] )
            : [];

        if ( empty( $row_ids ) ) {
            wp_send_json_error( [ 'message' => __( 'No items selected.', 'media-cleaner-pro' ) ] );
        }

        global $wpdb;
        $table = \MCP\DB\Schema::table( 'fs_duplicates' );

        $placeholders = implode( ',', array_fill( 0, count( $row_ids ), '%d' ) );
        $items = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, file_path, file_size, attachment_id FROM {$table} WHERE id IN ($placeholders)",
                ...$row_ids
            )
        );

        $deleted  = 0;
        $freed    = 0;
        $errors   = [];
        $skipped  = [];   // Files still in use — protected from deletion

        // Resolve uploads base once
        $uploads      = wp_upload_dir();
        $uploads_base = $uploads['basedir'];
        $uploads_url  = trailingslashit( $uploads['baseurl'] );

        foreach ( $items as $item ) {
            $size = (int) $item->file_size;
            $path = $item->file_path;

            // ── Resolve public URL for the in-use check ───────────────────────
            if ( $item->attachment_id ) {
                $file_url = wp_get_attachment_url( (int) $item->attachment_id ) ?: '';
            } else {
                $rel      = str_replace( '\\', '/', $path );
                $rel      = str_replace( str_replace( '\\', '/', trailingslashit( $uploads_base ) ), '', $rel );
                $file_url = $uploads_url . ltrim( $rel, '/' );
            }

            // ── Safety: skip any file actively used on a page/post ────────────
            if ( $this->is_file_in_use( $file_url, $path, $item->attachment_id ? (int) $item->attachment_id : null ) ) {
                $skipped[] = [
                    'path'   => $path,
                    'reason' => __( 'File is referenced in page/post content or site options.', 'media-cleaner-pro' ),
                ];
                continue;
            }

            if ( $item->attachment_id ) {
                // WP attachment — use wp_delete_attachment (removes DB entry + all thumbs)
                $result = wp_delete_attachment( (int) $item->attachment_id, true );
                if ( $result ) {
                    $deleted++;
                    $freed += $size;
                    // Clean up scan_results cache too
                    $wpdb->delete( \MCP\DB\Schema::table( 'scan_results' ), [ 'attachment_id' => (int) $item->attachment_id ], [ '%d' ] );

                    // Feature: automatically remove empty duplicate subdirectories left behind
                    $dir = dirname( $path );
                    while ( $dir && @is_dir( $dir ) && strlen( $dir ) > strlen( $uploads_base ) ) {
                        $contents = @scandir( $dir );
                        if ( is_array( $contents ) && count( $contents ) === 2 ) {
                            @rmdir( $dir );
                            $dir = dirname( $dir );
                        } else {
                            break;
                        }
                    }
                } else {
                    $errors[] = basename( $path ) . ' (wp_delete_attachment failed)';
                    continue;
                }
            } else {
                // Orphan file — just unlink (not registered in WP media library)

                // Safety: must be inside uploads/
                if ( strpos( realpath( $path ) ?: $path, realpath( $uploads_base ) ) !== 0 ) {
                    $errors[] = basename( $path ) . ' (blocked: outside uploads dir)';
                    continue;
                }

                if ( file_exists( $path ) ) {
                    if ( @unlink( $path ) ) {
                        $deleted++;
                        $freed += $size;

                        // Feature: automatically remove empty duplicate subdirectories left behind
                        $dir = dirname( $path );
                        while ( $dir && @is_dir( $dir ) && strlen( $dir ) > strlen( $uploads_base ) ) {
                            $contents = @scandir( $dir );
                            if ( is_array( $contents ) && count( $contents ) === 2 ) {
                                @rmdir( $dir );
                                $dir = dirname( $dir );
                            } else {
                                break;
                            }
                        }
                    } else {
                        $errors[] = basename( $path ) . ' (permission denied)';
                        continue;
                    }
                } else {
                    // File already gone from disk — count as deleted
                    $deleted++;
                }
            }

            // Remove the row from our fs_duplicates table
            $wpdb->delete( $table, [ 'id' => (int) $item->id ], [ '%d' ] );
        }

        // Build human-readable message
        $msg_parts = [];
        if ( $deleted > 0 ) {
            $msg_parts[] = sprintf(
                /* translators: 1: count, 2: space */
                __( '%1$d file(s) deleted (%2$s freed)', 'media-cleaner-pro' ),
                $deleted, size_format( $freed, 2 )
            );
        }
        if ( count( $skipped ) > 0 ) {
            $msg_parts[] = sprintf(
                /* translators: %d: count of protected files */
                __( '%d file(s) protected — still in use on a page/post', 'media-cleaner-pro' ),
                count( $skipped )
            );
        }
        if ( count( $errors ) > 0 ) {
            $msg_parts[] = sprintf(
                /* translators: %d: error count */
                __( '%d error(s)', 'media-cleaner-pro' ),
                count( $errors )
            );
        }

        wp_send_json_success( [
            'deleted'  => $deleted,
            'freed'    => $freed,
            'freed_hr' => size_format( $freed, 2 ),
            'skipped'  => $skipped,
            'errors'   => $errors,
            'message'  => implode( '. ', $msg_parts ) . '.',
        ] );
    }

    // ══════════════════════════════════════════════════════════════════════════
    // ONE-CLICK: Find & Auto-Delete (mcp_deep_dup_find_delete)
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Single AJAX call that:
     *   1. Walks every file in uploads/
     *   2. Groups by MD5 hash
     *   3. Skips originals (lowest ID / first seen) and in-use files
     *   4. Deletes all safe copies
     *   5. Returns a full summary report
     *
     * Uses set_time_limit(300) — safe for libraries up to ~5 GB.
     * For 9 GB+ libraries the batched flow (deep_start/batch/delete) is preferred.
     */
    public function deep_find_delete(): void {
        $this->verify();

        @set_time_limit( 300 );
        @ini_set( 'memory_limit', '256M' );

        try {
            global $wpdb;

            $uploads      = wp_upload_dir();
            $uploads_dir  = $uploads['basedir'];
            $uploads_base = trailingslashit( $uploads['basedir'] );
            $uploads_url  = trailingslashit( $uploads['baseurl'] );

            if ( ! is_dir( $uploads_dir ) ) {
                wp_send_json_error( [ 'message' => __( 'Uploads directory not found.', 'media-cleaner-pro' ) ] );
                return;
            }

            // ── Step 1: Index & hash every file ───────────────────────────────
            $files = $this->index_files( $uploads_dir );

            if ( empty( $files ) ) {
                wp_send_json_success( [
                    'scanned'  => 0, 'groups' => 0, 'deleted' => 0,
                    'skipped'  => 0, 'freed_hr' => '0 B',
                    'protected'=> [],
                    'message'  => __( 'No files found in uploads/', 'media-cleaner-pro' ),
                ] );
                return;
            }

            // Build attachment map for ALL files at once
            $attachment_map = $this->build_attachment_map( $files );

            // Hash & group: hash => [ [path, size, attachment_id], ... ]
            $hash_groups = [];
            foreach ( $files as $path ) {
                if ( ! file_exists( $path ) ) continue;
                $hash = md5_file( $path );
                if ( ! $hash ) continue;
                $size          = (int) filesize( $path );
                $attachment_id = $attachment_map[ $path ] ?? null;
                $hash_groups[ $hash ][] = compact( 'path', 'size', 'attachment_id' );
            }

            // Keep only hashes with 2+ files (real duplicates)
            $hash_groups = array_filter( $hash_groups, fn( $g ) => count( $g ) > 1 );

            if ( empty( $hash_groups ) ) {
                wp_send_json_success( [
                    'scanned'   => count( $files ),
                    'groups'    => 0,
                    'deleted'   => 0,
                    'skipped'   => 0,
                    'freed_hr'  => '0 B',
                    'protected' => [],
                    'message'   => __( 'No duplicate files found. Your uploads/ folder is clean!', 'media-cleaner-pro' ),
                ] );
                return;
            }

            // ── Step 2: Delete copies (keep index 0 = original) ───────────────
            $deleted   = 0;
            $freed     = 0;
            $skipped   = 0;
            $errors    = [];
            $protected = []; // files that are in-use (skipped safely)

            foreach ( $hash_groups as $hash => $group ) {
                // Keep the first item as original; delete the rest
                foreach ( $group as $idx => $item ) {
                    if ( $idx === 0 ) continue; // preserve original

                    $path          = $item['path'];
                    $size          = $item['size'];
                    $attachment_id = $item['attachment_id'];

                    // Resolve public URL for in-use check
                    if ( $attachment_id ) {
                        $file_url = wp_get_attachment_url( $attachment_id ) ?: '';
                    } else {
                        $rel      = str_replace( '\\', '/', $path );
                        $rel      = str_replace( str_replace( '\\', '/', $uploads_base ), '', $rel );
                        $file_url = $uploads_url . ltrim( $rel, '/' );
                    }

                    // 🔒 Safety: never delete files in use on pages/posts
                    if ( $this->is_file_in_use( $file_url, $path, $attachment_id ? (int)$attachment_id : null ) ) {
                        $skipped++;
                        $protected[] = basename( $path );
                        continue;
                    }

                    if ( $attachment_id ) {
                        $result = wp_delete_attachment( (int) $attachment_id, true );
                        if ( $result ) {
                            $deleted++;
                            $freed += $size;

                            $dir = dirname( $path );
                            while ( $dir && @is_dir( $dir ) && strlen( $dir ) > strlen( $uploads_dir ) ) {
                                $contents = @scandir( $dir );
                                if ( is_array( $contents ) && count( $contents ) === 2 ) {
                                    @rmdir( $dir );
                                    $dir = dirname( $dir );
                                } else {
                                    break;
                                }
                            }
                        } else {
                            $errors[] = basename( $path ) . ' (wp_delete_attachment failed)';
                        }
                    } else {
                        // Orphan — safety path check
                        if ( strpos( realpath( $path ) ?: $path, realpath( $uploads_dir ) ) !== 0 ) {
                            $errors[] = basename( $path ) . ' (blocked: outside uploads)';
                            continue;
                        }
                        if ( file_exists( $path ) && @unlink( $path ) ) {
                            $deleted++;
                            $freed += $size;

                            $dir = dirname( $path );
                            while ( $dir && @is_dir( $dir ) && strlen( $dir ) > strlen( $uploads_dir ) ) {
                                $contents = @scandir( $dir );
                                if ( is_array( $contents ) && count( $contents ) === 2 ) {
                                    @rmdir( $dir );
                                    $dir = dirname( $dir );
                                } else {
                                    break;
                                }
                            }
                        } elseif ( ! file_exists( $path ) ) {
                            $deleted++; // already gone
                        } else {
                            $errors[] = basename( $path ) . ' (permission denied)';
                        }
                    }
                }
            }

            // ── Build report ──────────────────────────────────────────────────
            $msg_parts = [];
            $msg_parts[] = sprintf( __( '%d duplicate group(s) found', 'media-cleaner-pro' ), count( $hash_groups ) );
            if ( $deleted > 0 )  $msg_parts[] = sprintf( __( '%d copy file(s) deleted (%s freed)', 'media-cleaner-pro' ), $deleted, size_format( $freed, 2 ) );
            if ( $skipped > 0 )  $msg_parts[] = sprintf( __( '%d file(s) protected (in use on a page/post)', 'media-cleaner-pro' ), $skipped );
            if ( count( $errors ) > 0 ) $msg_parts[] = sprintf( __( '%d error(s)', 'media-cleaner-pro' ), count( $errors ) );
            if ( $deleted === 0 && $skipped === 0 ) $msg_parts[] = __( 'Nothing to delete', 'media-cleaner-pro' );

            wp_send_json_success( [
                'scanned'   => count( $files ),
                'groups'    => count( $hash_groups ),
                'deleted'   => $deleted,
                'skipped'   => $skipped,
                'freed_hr'  => size_format( $freed, 2 ),
                'protected' => $protected,
                'errors'    => $errors,
                'message'   => implode( '. ', $msg_parts ) . '.',
            ] );

        } catch ( \Throwable $e ) {
            wp_send_json_error( [
                'message' => __( 'Find & Delete failed: ', 'media-cleaner-pro' ) . $e->getMessage(),
            ] );
        }
    }

    // ══════════════════════════════════════════════════════════════════════════
    // Private helpers
    // ══════════════════════════════════════════════════════════════════════════

    /**
     * Check whether a file is actively referenced anywhere in the WordPress
     * database — post_content, postmeta, options (site logo, background, etc.).
     *
     * Checks performed (all use LIKE %url%):
     *   1. wp_posts.post_content
     *   2. wp_postmeta.meta_value  (catches ACF, Elementor, page-builder data)
     *   3. wp_options.option_value (catches site logo, background image, etc.)
     *
     * Both the public URL and the raw file path are checked so that plugins
     * storing absolute paths instead of URLs are also covered.
     *
     * @param string $url   Public URL of the file.
     * @param string $path  Absolute disk path of the file (fallback for DB comparisons).
     * @return bool  true  = file IS in use — do NOT delete.
     *               false = file is safe to delete.
     */
    private function is_file_in_use( string $url, string $path, ?int $attachment_id = null ): bool {
        if ( empty( $url ) && empty( $path ) && ! $attachment_id ) return false;

        global $wpdb;

        if ( $attachment_id ) {
            // 1. Used as Featured Image (_thumbnail_id)
            $found_meta = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %s LIMIT 1",
                    (string) $attachment_id
                )
            );
            if ( $found_meta ) return true;

            // 2. Used as WooCommerce Gallery Image (_product_image_gallery) - comma separated IDs
            $found_woo = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_product_image_gallery' AND (meta_value = %s OR meta_value LIKE %s OR meta_value LIKE %s OR meta_value LIKE %s) LIMIT 1",
                    (string) $attachment_id,
                    $attachment_id . ',%',
                    '%,' . $attachment_id . ',%',
                    '%,' . $attachment_id
                )
            );
            if ( $found_woo ) return true;

            // 3. Used in Elementor or other JSON settings by ID (e.g. "id":123)
            $like_id_json = '%"id":' . $attachment_id . '%';
            $like_id_json2 = '%"id":"' . $attachment_id . '"%';
            $found_json = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_value LIKE %s OR meta_value LIKE %s LIMIT 1",
                    $like_id_json,
                    $like_id_json2
                )
            );
            if ( $found_json ) return true;
        }

        $needles = array_unique( array_filter( [ $url, $path ] ) );

        foreach ( $needles as $needle ) {
            $like = '%' . $wpdb->esc_like( $needle ) . '%';

            // 1. Post content (pages, posts, custom post types)
            $found = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts}
                     WHERE post_status NOT IN ('trash','auto-draft')
                       AND post_content LIKE %s
                     LIMIT 1",
                    $like
                )
            );
            if ( $found ) return true;

            // 2. Post meta (ACF fields, Elementor JSON, WooCommerce product data…)
            $found = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT post_id FROM {$wpdb->postmeta}
                     WHERE meta_value LIKE %s
                     LIMIT 1",
                    $like
                )
            );
            if ( $found ) return true;

            // 3. Options (site logo, custom background, theme settings…)
            $found = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT option_id FROM {$wpdb->options}
                     WHERE option_value LIKE %s
                       AND option_name NOT LIKE '\_transient%'
                       AND option_name NOT LIKE '\_site\_transient%'
                     LIMIT 1",
                    $like
                )
            );
            if ( $found ) return true;
        }

        return false;
    }

    /**
     * Recursively collect all file paths under $dir, filtered by EXTENSIONS.
     *
     * @return string[]
     */
    private function index_files( string $dir ): array {
        $files = [];

        try {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS | \FilesystemIterator::UNIX_PATHS ),
                \RecursiveIteratorIterator::LEAVES_ONLY
            );

            foreach ( $iterator as $file ) {
                /** @var \SplFileInfo $file */
                if ( ! $file->isFile() ) continue;

                $ext = strtolower( $file->getExtension() );
                if ( ! in_array( $ext, self::EXTENSIONS, true ) ) continue;

                // Skip zero-byte files
                if ( $file->getSize() === 0 ) continue;

                $files[] = $file->getPathname();
            }
        } catch ( \Exception $e ) {
            // Silently skip unreadable dirs
        }

        return $files;
    }

    /**
     * Build a map of file_path => attachment_id for a batch of files.
     * Uses a single query comparing _wp_attached_file postmeta values.
     *
     * @param  string[] $paths  Absolute file paths
     * @return array<string, int>  path => attachment_id (only for registered attachments)
     */
    private function build_attachment_map( array $paths ): array {
        global $wpdb;

        $uploads_base = trailingslashit( wp_upload_dir()['basedir'] );
        $map          = [];

        // Convert absolute paths to relative (as stored in _wp_attached_file)
        $relatives = [];
        foreach ( $paths as $abs ) {
            $rel = str_replace( $uploads_base, '', str_replace( '\\', '/', $abs ) );
            $relatives[ $rel ] = $abs;
        }

        if ( empty( $relatives ) ) return $map;

        $placeholders = implode( ',', array_fill( 0, count( $relatives ), '%s' ) );

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT post_id, meta_value
                 FROM {$wpdb->postmeta}
                 WHERE meta_key = '_wp_attached_file' AND meta_value IN ($placeholders)",
                ...array_keys( $relatives )
            )
        );

        foreach ( $rows as $row ) {
            $abs_path = $relatives[ $row->meta_value ] ?? null;
            if ( $abs_path ) {
                $map[ $abs_path ] = (int) $row->post_id;
            }
        }

        return $map;
    }
}
