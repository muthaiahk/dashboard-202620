<?php
namespace MCP\DB;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Handles custom DB table creation and upgrades.
 *
 * Tables:
 *  {prefix}mcp_scan_results  — stores the last scan output per type.
 *  {prefix}mcp_trash         — tracks soft-deleted attachments.
 *  {prefix}mcp_fs_duplicates — deep filesystem duplicate scan (includes orphans).
 */
final class Schema {

    public static function install(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();

        // ── Scan results cache ────────────────────────────────────────────────
        $sql_results = "CREATE TABLE {$wpdb->prefix}mcp_scan_results (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            scan_type    VARCHAR(50)     NOT NULL,
            attachment_id BIGINT UNSIGNED NOT NULL,
            file_path    TEXT            NOT NULL,
            file_size    BIGINT UNSIGNED NOT NULL DEFAULT 0,
            hash         VARCHAR(64)     NULL,
            scanned_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY scan_type (scan_type),
            KEY attachment_id (attachment_id)
        ) $charset;";

        // ── Soft-trash log ────────────────────────────────────────────────────
        $sql_trash = "CREATE TABLE {$wpdb->prefix}mcp_trash (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            attachment_id BIGINT UNSIGNED NOT NULL,
            original_path TEXT            NOT NULL,
            trashed_by    BIGINT UNSIGNED NOT NULL,
            trashed_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY   (id),
            UNIQUE KEY attachment_id (attachment_id)
        ) $charset;";

        // ── Deep filesystem duplicate table ───────────────────────────────────
        // Stores every file found on disk; attachment_id = NULL means orphan.
        $sql_fs_dups = "CREATE TABLE {$wpdb->prefix}mcp_fs_duplicates (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            file_path     TEXT            NOT NULL,
            file_size     BIGINT UNSIGNED NOT NULL DEFAULT 0,
            hash          VARCHAR(32)     NOT NULL,
            attachment_id BIGINT UNSIGNED NULL,
            scanned_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY   (id),
            KEY hash      (hash),
            KEY attachment_id (attachment_id)
        ) $charset;";

        dbDelta( $sql_results );
        dbDelta( $sql_trash );
        dbDelta( $sql_fs_dups );

        update_option( 'mcp_db_version', MCP_VERSION );
    }

    public static function deactivate(): void {
        // intentionally keeps data on deactivation; only uninstall.php drops tables
    }

    public static function table( string $name ): string {
        global $wpdb;
        return $wpdb->prefix . 'mcp_' . $name;
    }
}
