<?php
/**
 * Template: WebP Compression
 *
 * @package Media Cleaner Pro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$has_imagick = class_exists( 'Imagick' );
$has_gd_webp = function_exists( 'imagewebp' );
$supported   = $has_imagick || $has_gd_webp;
?>
<div class="wrap mcp-wrap">

    <div class="mcp-header">
        <div class="mcp-header__logo">
            <span class="dashicons dashicons-images-alt"></span>
            <div>
                <h1><?php esc_html_e( 'WebP Compression', 'media-cleaner-pro' ); ?></h1>
                <p><?php esc_html_e( 'Convert JPEG, PNG, and GIF images to WebP for smaller file sizes.', 'media-cleaner-pro' ); ?></p>
            </div>
        </div>
    </div>

    <!-- ── Server capability info ─────────────────────────────────────────── -->
    <div class="mcp-info-box">
        <h3><?php esc_html_e( 'Server Capability', 'media-cleaner-pro' ); ?></h3>
        <ul>
            <li><?php echo $has_imagick
                ? '<span class="mcp-badge mcp-badge--success">✓ Imagick</span> ' . esc_html__( '(preferred — best quality)', 'media-cleaner-pro' )
                : '<span class="mcp-badge mcp-badge--error">✗ Imagick</span> ' . esc_html__( '(not available)', 'media-cleaner-pro' ); ?></li>
            <li><?php echo $has_gd_webp
                ? '<span class="mcp-badge mcp-badge--success">✓ GD + WebP</span> ' . esc_html__( '(fallback available)', 'media-cleaner-pro' )
                : '<span class="mcp-badge mcp-badge--error">✗ GD WebP</span> '   . esc_html__( '(not available)', 'media-cleaner-pro' ); ?></li>
        </ul>
        <?php if ( ! $supported ) : ?>
            <p class="mcp-notice mcp-notice--error">
                <?php esc_html_e( 'WebP compression is not available on this server. Please enable Imagick or GD with WebP support.', 'media-cleaner-pro' ); ?>
            </p>
        <?php endif; ?>
    </div>

    <?php if ( $supported ) : ?>
    <div class="mcp-toolbar">
        <label>
            <strong><?php esc_html_e( 'Quality:', 'media-cleaner-pro' ); ?></strong>
            <input type="range" id="mcp-webp-quality" min="50" max="100" value="<?php echo esc_attr( MCP_WEBP_QUALITY ); ?>" step="1" style="vertical-align:middle;">
            <span id="mcp-webp-quality-val"><?php echo esc_html( MCP_WEBP_QUALITY ); ?></span>%
        </label>

        <button id="mcp-webp-btn" class="button button-primary mcp-btn-icon">
            <span class="dashicons dashicons-images-alt"></span>
            <?php esc_html_e( 'Start Conversion', 'media-cleaner-pro' ); ?>
        </button>
    </div>

    <div class="mcp-progress-wrap" id="mcp-webp-progress" style="display:none;">
        <div class="mcp-progress-bar">
            <div class="mcp-progress-bar__fill" id="mcp-webp-fill"></div>
        </div>
        <p id="mcp-webp-text">0%</p>
    </div>

    <div id="mcp-webp-notice" class="mcp-notice" style="display:none;"></div>

    <!-- ── Summary counters ───────────────────────────────────────────────── -->
    <div class="mcp-stats-grid mcp-stats-inline" id="mcp-webp-summary" style="display:none;">
        <div class="mcp-stat-card"><div class="mcp-stat-card__value" id="wc-converted">0</div><div class="mcp-stat-card__label"><?php esc_html_e( 'Converted', 'media-cleaner-pro' ); ?></div></div>
        <div class="mcp-stat-card"><div class="mcp-stat-card__value" id="wc-skipped">0</div><div class="mcp-stat-card__label"><?php esc_html_e( 'Skipped',   'media-cleaner-pro' ); ?></div></div>
        <div class="mcp-stat-card"><div class="mcp-stat-card__value" id="wc-saved">0 B</div><div class="mcp-stat-card__label"><?php esc_html_e( 'Space Saved', 'media-cleaner-pro' ); ?></div></div>
    </div>

    <div id="mcp-webp-log" class="mcp-log" style="display:none;"></div>
    <?php endif; ?>

</div>

<script>
jQuery(function ($) {

    $('#mcp-webp-quality').on('input', function () {
        $('#mcp-webp-quality-val').text($(this).val());
    });

    var totalConverted = 0, totalSkipped = 0, totalSaved = 0;

    $('#mcp-webp-btn').on('click', function () {
        totalConverted = totalSkipped = totalSaved = 0;
        $('#mcp-webp-log').empty().show();
        $('#mcp-webp-summary').hide();
        $('#mcp-webp-notice').hide();
        $(this).prop('disabled', true).find('.dashicons').addClass('spin');

        $.post(MCP.ajax_url, { action: 'mcp_webp_start', nonce: MCP.nonce })
            .done(function (res) {
                if (!res.success) { notice(res.data.message, 'error'); resetBtn(); return; }
                if (res.data.total === 0) { notice('No convertible images found.', 'info'); resetBtn(); return; }
                runBatch(0, res.data.total);
            });
    });

    function runBatch(offset, total) {
        var pct = total > 0 ? Math.round(offset / total * 100) : 0;
        showProg(pct, offset);

        $.post(MCP.ajax_url, {
            action: 'mcp_webp_batch', nonce: MCP.nonce,
            offset: offset, total: total,
            quality: $('#mcp-webp-quality').val()
        }).done(function (res) {
            if (!res.success) { notice(res.data.message, 'error'); resetBtn(); return; }
            var d = res.data;

            totalConverted += d.converted;
            totalSkipped   += d.skipped;
            totalSaved     += d.saved;

            d.items.forEach(function (item) {
                $('#mcp-webp-log').append(
                    '<div class="mcp-log-row">✓ ID ' + item.id + ' | ' +
                    escHtml(item.original) + ' → ' + escHtml(item.webp) +
                    ' <span class="mcp-badge mcp-badge--success">-' + escHtml(item.saved) + '</span></div>'
                );
            });

            if (!d.done) {
                runBatch(d.processed, total);
            } else {
                showProg(100, total);
                hideProg();
                resetBtn();
                $('#wc-converted').text(totalConverted);
                $('#wc-skipped').text(totalSkipped);
                $('#wc-saved').text(formatBytes(totalSaved));
                $('#mcp-webp-summary').show();
                notice('Conversion complete. ' + totalConverted + ' image(s) converted, ' + formatBytes(totalSaved) + ' saved.', 'success');
            }
        });
    }

    function showProg(pct, done) {
        $('#mcp-webp-progress').show();
        $('#mcp-webp-fill').css('width', pct + '%');
        $('#mcp-webp-text').text(pct + '% (' + done + ' processed)');
    }

    function hideProg() { setTimeout(function () { $('#mcp-webp-progress').fadeOut(); }, 1500); }

    function notice(msg, type) {
        $('#mcp-webp-notice')
            .removeClass('mcp-notice--success mcp-notice--error mcp-notice--info')
            .addClass('mcp-notice--' + type).html(msg).show();
    }

    function resetBtn() {
        $('#mcp-webp-btn').prop('disabled', false).find('.dashicons').removeClass('spin');
    }

    function formatBytes(b) {
        if (b < 1024) return b + ' B';
        if (b < 1048576) return (b/1024).toFixed(2) + ' KB';
        return (b/1048576).toFixed(2) + ' MB';
    }

    function escHtml(str) { return $('<div>').text(str).html(); }
});
</script>
