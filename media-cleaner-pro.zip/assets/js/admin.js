/**
 * Media Cleaner Pro — Admin JS (shared utilities only).
 * Page-specific logic lives inline in each template for simplicity,
 * but shared helpers are available globally via window.MCP_Utils.
 */
(function ($) {
    'use strict';

    window.MCP_Utils = {

        /**
         * Show a toast-style notice in a given container selector.
         * @param {string} selector   jQuery selector for notice div
         * @param {string} message    HTML message
         * @param {string} type       success|error|info
         * @param {number} autoHide   ms before auto-hide (0 = never)
         */
        notice: function (selector, message, type, autoHide) {
            var $el = $(selector);
            $el.removeClass('mcp-notice--success mcp-notice--error mcp-notice--info')
               .addClass('mcp-notice--' + (type || 'info'))
               .html(message)
               .stop(true).show();

            if (autoHide && autoHide > 0) {
                setTimeout(function () { $el.fadeOut(); }, autoHide);
            }
        },

        /**
         * Update a progress bar and its label.
         * @param {string} fillSelector  jQuery selector for .mcp-progress-bar__fill
         * @param {string} textSelector  jQuery selector for the percentage label
         * @param {number} pct           0–100
         * @param {string} label         Optional extra text
         */
        progress: function (fillSelector, textSelector, pct, label) {
            $(fillSelector).css('width', Math.min(100, pct) + '%');
            var text = Math.round(pct) + '%';
            if (label) text += ' — ' + label;
            $(textSelector).text(text);
        },

        /**
         * Collect checked checkbox values as an array of integers.
         * @param {string} checkboxSelector
         * @returns {number[]}
         */
        getCheckedIds: function (checkboxSelector) {
            return $.map($(checkboxSelector + ':checked'), function (el) {
                return parseInt($(el).val(), 10);
            });
        },

        /**
         * Fade out and remove table rows by attachment ID.
         * @param {number[]} ids
         * @param {string}   rowSelector  e.g. 'tr'
         */
        removeRows: function (ids, rowSelector) {
            ids.forEach(function (id) {
                $(rowSelector + '[data-id="' + id + '"]').fadeOut(280, function () {
                    $(this).remove();
                });
            });
        },

        /**
         * Safe HTML escape.
         * @param {string} str
         * @returns {string}
         */
        esc: function (str) {
            return $('<div>').text(str).html();
        },

        /**
         * Format bytes to human-readable string (client-side).
         * @param {number} bytes
         * @returns {string}
         */
        formatBytes: function (bytes) {
            if (bytes < 1024)       return bytes + ' B';
            if (bytes < 1048576)    return (bytes / 1024).toFixed(2) + ' KB';
            if (bytes < 1073741824) return (bytes / 1048576).toFixed(2) + ' MB';
            return (bytes / 1073741824).toFixed(2) + ' GB';
        }
    };

    // ── Global "select all" convenience ──────────────────────────────────────
    $(document).on('change', '#mcp-select-all, #mcp-table-select-all, #mcp-trash-select-all', function () {
        var checked = $(this).is(':checked');
        $(this).closest('.mcp-wrap').find('input[type="checkbox"].mcp-row-check, input[type="checkbox"].mcp-trash-check').prop('checked', checked);
    });

}(jQuery));
