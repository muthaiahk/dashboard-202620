<?php
namespace MCP\Ajax;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Shared AJAX utilities.
 */
trait AjaxTrait {

    /** Verify nonce + cap, then return decoded JSON body. Kills on failure. */
    protected function verify(): void {
        if ( ! check_ajax_referer( 'mcp_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed.', 'media-cleaner-pro' ) ], 403 );
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'media-cleaner-pro' ) ], 403 );
        }
    }

    protected function int_param( string $key, int $default = 0 ): int {
        return isset( $_POST[ $key ] ) ? (int) sanitize_text_field( $_POST[ $key ] ) : $default;
    }

    protected function array_param( string $key ): array {
        if ( empty( $_POST[ $key ] ) || ! is_array( $_POST[ $key ] ) ) {
            return [];
        }
        return array_map( 'absint', $_POST[ $key ] );
    }
}
