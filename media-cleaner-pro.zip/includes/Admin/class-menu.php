<?php
namespace MCP\Admin;

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Registers admin menu pages and sub-pages.
 */
final class Menu {

    public function __construct() {
        add_action( 'admin_menu', [ $this, 'register_pages' ] );
    }

    public function register_pages(): void {
        add_menu_page(
            __( 'Media Cleaner Pro', 'media-cleaner-pro' ),
            __( 'Media Cleaner', 'media-cleaner-pro' ),
            'manage_options',
            'mcp-dashboard',
            [ $this, 'page_dashboard' ],
            'dashicons-editor-removeformatting',
            58
        );

        add_submenu_page(
            'mcp-dashboard',
            __( 'Dashboard',         'media-cleaner-pro' ),
            __( 'Dashboard',         'media-cleaner-pro' ),
            'manage_options',
            'mcp-dashboard',
            [ $this, 'page_dashboard' ]
        );

        add_submenu_page(
            'mcp-dashboard',
            __( 'Unused Media',      'media-cleaner-pro' ),
            __( 'Unused Media',      'media-cleaner-pro' ),
            'manage_options',
            'mcp-unused',
            [ $this, 'page_unused' ]
        );

        add_submenu_page(
            'mcp-dashboard',
            __( 'Duplicate Finder',  'media-cleaner-pro' ),
            __( 'Duplicates',        'media-cleaner-pro' ),
            'manage_options',
            'mcp-duplicates',
            [ $this, 'page_duplicates' ]
        );

        add_submenu_page(
            'mcp-dashboard',
            __( 'WebP Compression',  'media-cleaner-pro' ),
            __( 'WebP Compression',  'media-cleaner-pro' ),
            'manage_options',
            'mcp-webp',
            [ $this, 'page_webp' ]
        );

        add_submenu_page(
            'mcp-dashboard',
            __( 'Trash',             'media-cleaner-pro' ),
            __( 'Trash',             'media-cleaner-pro' ),
            'manage_options',
            'mcp-trash',
            [ $this, 'page_trash' ]
        );

        add_submenu_page(
            'mcp-dashboard',
            __( 'Settings',          'media-cleaner-pro' ),
            __( 'Settings',          'media-cleaner-pro' ),
            'manage_options',
            'mcp-settings',
            [ $this, 'page_settings' ]
        );
    }

    // ── Page renderers — each loads a template ────────────────────────────────

    public function page_dashboard():  void { $this->render( 'dashboard' );  }
    public function page_unused():     void { $this->render( 'unused' );     }
    public function page_duplicates(): void { $this->render( 'duplicates' ); }
    public function page_webp():       void { $this->render( 'webp' );       }
    public function page_trash():      void { $this->render( 'trash' );      }
    public function page_settings():   void { $this->render( 'settings' );   }

    private function render( string $template ): void {
        $file = MCP_PLUGIN_DIR . 'templates/' . $template . '.php';
        if ( file_exists( $file ) ) {
            require $file;
        } else {
            /* translators: %s: template file name */
            echo '<div class="wrap"><p>' . sprintf( esc_html__( 'Template not found: %s', 'media-cleaner-pro' ), esc_html( $template ) ) . '</p></div>';
        }
    }
}
