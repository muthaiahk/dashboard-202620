<?php
namespace MCP\Ajax;

if ( ! defined( 'ABSPATH' ) ) exit;

require_once MCP_INCLUDES . 'Ajax/trait-ajax.php';

/**
 * AJAX Scan handler — batched, no PHP timeout risk.
 *
 * Flow:
 *  1. JS calls mcp_scan_start → returns {total, nonce}
 *  2. JS calls mcp_scan_batch?offset=N repeatedly until done=true
 *  3. Results cached in {prefix}mcp_scan_results
 *
 * Supported scan types: unused | large | all
 */
final class Scan {

    use AjaxTrait;

    public function __construct() {
        add_action( 'wp_ajax_mcp_scan_start', [ $this, 'handle_start' ] );
        add_action( 'wp_ajax_mcp_scan_batch', [ $this, 'handle_batch' ] );
    }

    // ── Step 1: count total attachments and clear old results ─────────────────
    public function handle_start(): void {
        $this->verify();

        $type = sanitize_key( $_POST['scan_type'] ?? 'unused' );
        $type = in_array( $type, [ 'unused', 'large', 'all' ], true ) ? $type : 'unused';

        global $wpdb;

        // Clear previous results for this type
        $wpdb->delete(
            \MCP\DB\Schema::table( 'scan_results' ),
            [ 'scan_type' => $type ],
            [ '%s' ]
        );

        $total = (int) $wpdb->get_var(
            "SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit'"
        );

        wp_send_json_success( [
            'total'     => $total,
            'scan_type' => $type,
        ] );
    }

    // ── Step 2: process one batch ─────────────────────────────────────────────
    public function handle_batch(): void {
        $this->verify();

        $type   = sanitize_key( $_POST['scan_type'] ?? 'unused' );
        $offset = $this->int_param( 'offset', 0 );
        $limit  = MCP_BATCH_SIZE;
        $total  = $this->int_param( 'total', 0 );

        global $wpdb;

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type = 'attachment' AND post_status = 'inherit'
             ORDER BY ID ASC
             LIMIT %d OFFSET %d",
            $limit,
            $offset
        ) );

        $found = [];

        foreach ( $rows as $row ) {
            $id = (int) $row->ID;

            if ( in_array( $type, [ 'unused', 'all' ], true ) ) {
                if ( $this->is_unused( $id ) ) {
                    $found[] = $this->build_result( $id, $type );
                    $this->cache_result( $id, $type );
                    continue;
                }
            }

            if ( in_array( $type, [ 'large', 'all' ], true ) ) {
                $path = get_attached_file( $id );
                if ( $path && file_exists( $path ) && filesize( $path ) > 5 * 1024 * 1024 ) {
                    $found[] = $this->build_result( $id, 'large' );
                    $this->cache_result( $id, 'large' );
                }
            }
        }

        $processed = $offset + count( $rows );
        $done      = $processed >= $total || count( $rows ) === 0;

        wp_send_json_success( [
            'items'     => $found,
            'processed' => $processed,
            'done'      => $done,
        ] );
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function is_unused( int $id ): bool {
        global $wpdb;

        // Check post_parent (featured images, attached)
        if ( (int) get_post( $id )->post_parent > 0 ) {
            return false;
        }

        // Check if set as featured image anywhere
        $used_thumb = $wpdb->get_var( $wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %d LIMIT 1",
            $id
        ) );
        if ( $used_thumb ) return false;

        $url = wp_get_attachment_url( $id );
        if ( ! $url ) return true;

        // Check post_content
        $used_content = $wpdb->get_var( $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_content LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like( $url ) . '%'
        ) );
        if ( $used_content ) return false;

        // Check postmeta (Elementor, ACF, page builders)
        $used_meta = $wpdb->get_var( $wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_value LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like( $url ) . '%'
        ) );
        if ( $used_meta ) return false;

        // Check options (site logo, background etc.)
        $used_opt = $wpdb->get_var( $wpdb->prepare(
            "SELECT option_id FROM {$wpdb->options} WHERE option_value LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like( $url ) . '%'
        ) );
        if ( $used_opt ) return false;

        return true;
    }

    private function build_result( int $id, string $type ): array {
        $path = get_attached_file( $id );
        $size = ( $path && file_exists( $path ) ) ? filesize( $path ) : 0;

        return [
            'id'        => $id,
            'title'     => get_the_title( $id ),
            'url'       => wp_get_attachment_url( $id ),
            'thumb'     => wp_get_attachment_image_url( $id, 'thumbnail' ),
            'size'      => $size,
            'size_hr'   => size_format( $size, 2 ),
            'mime'      => get_post_mime_type( $id ),
            'scan_type' => $type,
        ];
    }

    private function cache_result( int $id, string $type ): void {
        global $wpdb;
        $path = get_attached_file( $id );
        $size = ( $path && file_exists( $path ) ) ? filesize( $path ) : 0;

        $wpdb->replace(
            \MCP\DB\Schema::table( 'scan_results' ),
            [
                'scan_type'     => $type,
                'attachment_id' => $id,
                'file_path'     => $path ?? '',
                'file_size'     => $size,
                'scanned_at'    => current_time( 'mysql' ),
            ],
            [ '%s', '%d', '%s', '%d', '%s' ]
        );
    }
}
